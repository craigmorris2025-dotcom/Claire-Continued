"""Claire Syntalion Backend — FastAPI server + 24-engine pipeline."""
__version__ = "4.0.0"
