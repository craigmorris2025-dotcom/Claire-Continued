﻿"""Auto-Update Engine â€” Claire Syntalion v4.2"""
import json, pathlib, logging, aiohttp, zipfile

logger = logging.getLogger("claire.update")
BASE_DIR = pathlib.Path(__file__).resolve().parents[3]
VERSION_FILE = BASE_DIR / "version.json"
UPDATE_URL = "https://your-update-server.com/claire/latest.json"
PACKAGE_URL = "https://your-update-server.com/claire/packages/"

async def fetch_json(url):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            if resp.status != 200: return None
            return await resp.json()

def load_local_version():
    if not VERSION_FILE.exists(): return {"version": "0.0.0"}
    return json.loads(VERSION_FILE.read_text())

def save_local_version(data):
    VERSION_FILE.write_text(json.dumps(data, indent=2))

async def download_update(name, dest):
    async with aiohttp.ClientSession() as session:
        async with session.get(PACKAGE_URL + name) as resp:
            if resp.status != 200: return False
            dest.write_bytes(await resp.read())
            return True

def apply_update(zip_path):
    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(BASE_DIR)

async def check_for_updates():
    logger.info("Checking for updates...")
    local = load_local_version()
    remote = await fetch_json(UPDATE_URL)
    if not remote: return False
    if remote["version"] == local["version"]: return False

    pkg = remote["package"]
    zip_path = BASE_DIR / pkg
    ok = await download_update(pkg, zip_path)
    if not ok: return False

    apply_update(zip_path)
    zip_path.unlink(missing_ok=True)
    save_local_version(remote)
    logger.info(f"Updated to {remote["version"]}")
    return True
