"""Bridge — MasterPass handoff layer."""
