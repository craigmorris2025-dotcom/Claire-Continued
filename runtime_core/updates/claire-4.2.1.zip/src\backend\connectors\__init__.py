"""External Data Connectors — market, patent, financial."""
from src.backend.connectors.manager import ConnectorManager
