"""
24 Domain Engines — Auto-discovery registry.
Imports all engines and builds DOMAIN_REGISTRY + PHASE_SEQUENCE.
"""
from src.backend.engines.ingestion import IngestionEngine
from src.backend.engines.semantic import SemanticEngine
from src.backend.engines.fusion import FusionEngine
from src.backend.engines.company import CompanyEngine
from src.backend.engines.engineering import EngineeringEngine
from src.backend.engines.product import ProductEngine
from src.backend.engines.customer import CustomerEngine
from src.backend.engines.competitive import CompetitiveEngine
from src.backend.engines.operational import OperationalEngine
from src.backend.engines.financial import FinancialEngine
from src.backend.engines.synergy import SynergyEngine
from src.backend.engines.strategy import StrategyEngine
from src.backend.engines.risk import RiskEngine
from src.backend.engines.market import MarketEngine
from src.backend.engines.innovation import InnovationEngine
from src.backend.engines.breakthrough import BreakthroughEngine
from src.backend.engines.predictive import PredictiveEngine
from src.backend.engines.forecasting import ForecastingEngine
from src.backend.engines.deal import DealEngine
from src.backend.engines.decision import DecisionEngine
from src.backend.engines.discovery import DiscoveryEngine
from src.backend.engines.acquirer_matching import AcquirermatchingEngine
from src.backend.engines.portfolio import PortfolioEngine
from src.backend.engines.compliance import ComplianceEngine

# Ordered engine instances
_ALL_ENGINES = [
    IngestionEngine(), SemanticEngine(), FusionEngine(),
    CompanyEngine(), EngineeringEngine(), ProductEngine(),
    CustomerEngine(), CompetitiveEngine(), OperationalEngine(), FinancialEngine(),
    SynergyEngine(), StrategyEngine(), RiskEngine(), MarketEngine(),
    InnovationEngine(), BreakthroughEngine(), PredictiveEngine(), ForecastingEngine(),
    DealEngine(), DecisionEngine(), DiscoveryEngine(), AcquirermatchingEngine(),
    PortfolioEngine(), ComplianceEngine(),
]

# Key → engine instance
DOMAIN_REGISTRY = {e.get_key(): e for e in _ALL_ENGINES}

# Phase → [engine_keys] in execution order
PHASE_SEQUENCE = [
    ("ingestion_semantic", ["ingestion", "semantic", "fusion"]),
    ("intel_scoring", ["company", "engineering", "product", "customer",
                       "competitive", "operational", "financial"]),
    ("strategic_analysis", ["synergy", "strategy", "risk", "market"]),
    ("innovation_breakthrough", ["innovation", "breakthrough", "predictive", "forecasting"]),
    ("deal_construction", ["deal", "decision", "discovery", "acquirer_matching"]),
    ("portfolio_compliance", ["portfolio", "compliance"]),
]
