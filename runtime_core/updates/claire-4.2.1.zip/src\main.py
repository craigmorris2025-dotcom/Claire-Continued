﻿"""
Unified Backend Entry Point â€” Claire Syntalion v4.2
"""
from backend.server import create_app

app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "src.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
