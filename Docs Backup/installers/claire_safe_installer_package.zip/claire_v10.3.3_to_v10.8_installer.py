#!/usr/bin/env python3
"""
Claire v10.3.3 → v10.8 Advanced Subsystems Installer
=====================================================
ACS2-Claire / Syntalion — v10.3.2 → v10.8

Six new governed subsystems spanning advanced intelligence layers:
  1. Governed Live Research    (v10.3.3) — Source-verified live research with
                                           citation lineage, evidence quality,
                                           conflict resolution, claim verification
  2. Longitudinal Learning     (v10.4)   — Cross-run pattern mining, thesis
                                           evolution, recurring gap detection,
                                           learning signal extraction
  3. Validation Benchmarks     (v10.5)   — Regime & signal backtesting, false
                                           positive/negative analysis, outcome
                                           labeling, benchmark reporting
  4. Design Proof & Renderers  (v10.6)   — Architecture feasibility, dependency
                                           risk, cost modeling, build sequencing,
                                           graph rendering, blueprint export
  5. Technology Intelligence   (v10.7)   — Compatibility engine, stack recommender,
                                           integration complexity, component matching,
                                           deployment assessment, model governance
  6. Autonomous Governance     (v10.8)   — Action policy, self-change permissions,
                                           decision audit, escalation boundaries,
                                           human review gates, autonomy maturity

Plus: governed data directories for each subsystem.

USAGE:
  python claire_v10.3.3_to_v10.8_installer.py                     # Dry run
  python claire_v10.3.3_to_v10.8_installer.py --install            # Install all
  python claire_v10.3.3_to_v10.8_installer.py --install --phase 1  # Single phase
  python claire_v10.3.3_to_v10.8_installer.py --target ./Claire    # Custom path

BASE PATH: C:\\Users\\craig\\OneDrive\\Desktop\\Claire\\

SPEC SOURCES:
  - Tree 10.3.3-10.8.txt — Target folder/file tree
  - Files and folders tree 10.3.3_10.8.txt — Full path manifest
  - v10.3.0 / v10.3.1 / v10.3.2 installer packages

TOTAL: 56 new files, 36 new folders, 6 phases
"""

import os, sys, json, argparse, hashlib
from datetime import datetime
from pathlib import Path

# ============================================================================
#  CONFIGURATION
# ============================================================================

DEFAULT_TARGET = os.path.expanduser("~/OneDrive/Desktop/Claire")
INSTALLER_VERSION = "10.3.3-10.8"
INSTALLER_DATE = "2026-05-06"
INSTALLER_ID = hashlib.md5(f"claire_adv_subsystems_{INSTALLER_DATE}".encode()).hexdigest()[:12]

# ============================================================================
#  PHASE DEFINITIONS — 6 PHASES, 56 NEW FILES, 36 NEW FOLDERS
# ============================================================================

PHASES = [

# ──────────────────────────────────────────────────────────────────────────
#  PHASE 1: GOVERNED LIVE RESEARCH (v10.3.3)
#  Source-verified live research with citation lineage, evidence scoring,
#  conflict resolution, and claim verification
# ──────────────────────────────────────────────────────────────────────────
{
    "phase": 1,
    "name": "Governed Live Research",
    "version": "v10.3.3",
    "description": "Source-verified live research with citation lineage, evidence quality scoring, conflict resolution, and claim verification",
    "depends_on": [],
    "new_folders": [
        "src/claire/research",
        "src/claire/research/live",
        "data/research/live_packets",
        "data/research/verified_sources",
        "data/research/citation_lineage",
        "data/research/conflict_reports",
    ],
    "new_files": {
        "src/claire/research/__init__.py": {
            "role": "Research package init",
            "content_spec": "Package marker for claire.research namespace. Exports: governed_live_research, source_verification_engine, citation_lineage_engine, evidence_quality_scorer, evidence_conflict_resolver, claim_verifier, research_packet_builder"
        },
        "src/claire/research/live/__init__.py": {
            "role": "Live research sub-package init",
            "content_spec": "Package marker. Exports: GovernedLiveResearch, SourceVerificationEngine, CitationLineageEngine, EvidenceQualityScorer, EvidenceConflictResolver, ClaimVerifier, ResearchPacketBuilder"
        },
        "src/claire/research/live/governed_live_research.py": {
            "role": "Orchestrator for governed live research runs",
            "content_spec": "Class GovernedLiveResearch. Methods: execute_research(query, config) -> ResearchPacket, validate_sources(sources) -> VerificationResult, build_citation_chain(findings) -> CitationLineage, score_evidence(evidence_list) -> QualityReport, resolve_conflicts(conflicting_claims) -> ResolutionReport, verify_claims(claims) -> VerificationReport, package_results(results) -> ResearchPacket. Orchestrates full pipeline: source discovery -> verification -> evidence scoring -> conflict resolution -> claim verification -> packet assembly. Depends on all sibling modules. Emits structured JSON to data/research/live_packets/."
        },
        "src/claire/research/live/source_verification_engine.py": {
            "role": "Verifies authenticity and reliability of live data sources",
            "content_spec": "Class SourceVerificationEngine. Methods: verify_source(source_url, metadata) -> SourceVerdict, check_domain_authority(domain) -> AuthorityScore, validate_publication_date(source) -> DateValidation, cross_reference_source(source, known_sources) -> CrossRefResult, compute_trust_score(source) -> float, register_verified_source(source, verdict) -> None. Writes verified sources to data/research/verified_sources/. Trust scoring uses domain authority, publication recency, cross-reference density."
        },
        "src/claire/research/live/citation_lineage_engine.py": {
            "role": "Tracks citation chains and provenance of research claims",
            "content_spec": "Class CitationLineageEngine. Methods: build_lineage(claim, sources) -> LineageGraph, trace_origin(claim) -> OriginPath, validate_chain(lineage) -> ChainValidation, detect_circular_citations(lineage) -> list, export_lineage(lineage) -> dict, merge_lineages(lineage_a, lineage_b) -> LineageGraph. Stores lineage graphs in data/research/citation_lineage/. Each node carries source_id, timestamp, confidence_score."
        },
        "src/claire/research/live/evidence_quality_scorer.py": {
            "role": "Scores quality and strength of gathered evidence",
            "content_spec": "Class EvidenceQualityScorer. Methods: score_evidence(evidence) -> QualityScore, evaluate_methodology(evidence) -> MethodologyRating, assess_sample_size(evidence) -> SampleAssessment, check_recency(evidence) -> RecencyScore, compute_aggregate_quality(scores) -> float, rank_evidence(evidence_list) -> list. Multi-dimensional scoring: methodology rigor, sample adequacy, temporal relevance, source authority, reproducibility."
        },
        "src/claire/research/live/evidence_conflict_resolver.py": {
            "role": "Detects and resolves conflicts between evidence claims",
            "content_spec": "Class EvidenceConflictResolver. Methods: detect_conflicts(evidence_list) -> list[Conflict], classify_conflict(conflict) -> ConflictType, resolve_by_authority(conflict) -> Resolution, resolve_by_recency(conflict) -> Resolution, resolve_by_consensus(conflict) -> Resolution, generate_conflict_report(conflicts, resolutions) -> ConflictReport. Writes conflict reports to data/research/conflict_reports/. ConflictType enum: CONTRADICTORY, PARTIAL_OVERLAP, OUTDATED, METHODOLOGICAL."
        },
        "src/claire/research/live/claim_verifier.py": {
            "role": "Verifies individual claims against evidence base",
            "content_spec": "Class ClaimVerifier. Methods: verify_claim(claim, evidence_base) -> ClaimVerdict, find_supporting_evidence(claim) -> list, find_contradicting_evidence(claim) -> list, compute_confidence(claim, evidence) -> float, flag_unverifiable(claim) -> bool, batch_verify(claims) -> list[ClaimVerdict]. ClaimVerdict contains: claim_text, verdict (VERIFIED|UNVERIFIED|CONTESTED|INSUFFICIENT), confidence, supporting_refs, contradicting_refs."
        },
        "src/claire/research/live/research_packet_builder.py": {
            "role": "Assembles final research packets from verified findings",
            "content_spec": "Class ResearchPacketBuilder. Methods: build_packet(query, findings, lineage, quality_scores, resolutions) -> ResearchPacket, attach_metadata(packet, metadata) -> ResearchPacket, validate_packet(packet) -> ValidationResult, serialize_packet(packet) -> dict, save_packet(packet, output_dir) -> Path, load_packet(path) -> ResearchPacket. ResearchPacket is the canonical output artifact. Saved as timestamped JSON to data/research/live_packets/."
        },
    },
},

# ──────────────────────────────────────────────────────────────────────────
#  PHASE 2: LONGITUDINAL LEARNING (v10.4)
#  Cross-run pattern mining, thesis evolution tracking, recurring gap
#  detection, learning signal extraction, strategy memory synthesis
# ──────────────────────────────────────────────────────────────────────────
{
    "phase": 2,
    "name": "Longitudinal Learning",
    "version": "v10.4",
    "description": "Cross-run pattern mining, thesis evolution tracking, recurring gap detection, learning signal extraction, strategy memory synthesis",
    "depends_on": [1],
    "new_folders": [
        "src/claire/recursive",
        "src/claire/recursive/longitudinal",
        "data/recursive/run_patterns",
        "data/recursive/thesis_evolution",
        "data/recursive/recurring_gaps",
        "data/recursive/learning_signals",
        "data/recursive/quality_scores",
    ],
    "new_files": {
        "src/claire/recursive/__init__.py": {
            "role": "Recursive package init",
            "content_spec": "Package marker for claire.recursive namespace. Exports longitudinal sub-package."
        },
        "src/claire/recursive/longitudinal/__init__.py": {
            "role": "Longitudinal learning sub-package init",
            "content_spec": "Package marker. Exports: RunPatternMiner, ThesisEvolutionTracker, RecurringGapDetector, LearningSignalExtractor, StrategyMemorySynthesizer, RecursiveQualityScorer"
        },
        "src/claire/recursive/longitudinal/run_pattern_miner.py": {
            "role": "Mines patterns across historical run data",
            "content_spec": "Class RunPatternMiner. Methods: mine_patterns(run_history) -> list[Pattern], detect_recurring_themes(runs) -> list[Theme], compute_pattern_frequency(pattern, runs) -> float, rank_patterns_by_impact(patterns) -> list, cluster_similar_runs(runs) -> list[Cluster], export_patterns(patterns) -> dict. Reads from data/runs/run_history.json. Writes discovered patterns to data/recursive/run_patterns/. Pattern contains: pattern_id, description, frequency, first_seen, last_seen, impact_score."
        },
        "src/claire/recursive/longitudinal/thesis_evolution_tracker.py": {
            "role": "Tracks how research theses evolve across runs",
            "content_spec": "Class ThesisEvolutionTracker. Methods: track_thesis(thesis_id, run_data) -> ThesisTimeline, detect_thesis_drift(timeline) -> DriftReport, compare_thesis_versions(v1, v2) -> ThesisDiff, compute_convergence_score(timeline) -> float, identify_pivot_points(timeline) -> list, export_evolution(timeline) -> dict. Writes thesis evolution data to data/recursive/thesis_evolution/. Tracks confidence trajectory, evidence accumulation, and directional shifts."
        },
        "src/claire/recursive/longitudinal/recurring_gap_detector.py": {
            "role": "Identifies gaps that recur across multiple runs",
            "content_spec": "Class RecurringGapDetector. Methods: detect_gaps(run_history) -> list[Gap], classify_gap(gap) -> GapType, compute_recurrence_rate(gap) -> float, prioritize_gaps(gaps) -> list, suggest_remediation(gap) -> RemediationPlan, export_gaps(gaps) -> dict. GapType enum: DATA_MISSING, METHODOLOGY_WEAK, COVERAGE_INCOMPLETE, TEMPORAL_BLIND_SPOT. Writes to data/recursive/recurring_gaps/."
        },
        "src/claire/recursive/longitudinal/learning_signal_extractor.py": {
            "role": "Extracts actionable learning signals from run outcomes",
            "content_spec": "Class LearningSignalExtractor. Methods: extract_signals(run_outcome) -> list[Signal], classify_signal(signal) -> SignalType, measure_signal_strength(signal) -> float, correlate_signals(signals) -> CorrelationMatrix, filter_noise(signals, threshold) -> list, export_signals(signals) -> dict. SignalType enum: IMPROVEMENT, REGRESSION, PLATEAU, ANOMALY, BREAKTHROUGH. Writes to data/recursive/learning_signals/."
        },
        "src/claire/recursive/longitudinal/strategy_memory_synthesizer.py": {
            "role": "Synthesizes strategic memory from accumulated learning",
            "content_spec": "Class StrategyMemorySynthesizer. Methods: synthesize_memory(patterns, signals, gaps) -> StrategyMemory, update_memory(existing, new_data) -> StrategyMemory, query_memory(query) -> list[MemoryEntry], prune_stale_entries(memory, max_age_days) -> StrategyMemory, compute_memory_health(memory) -> HealthReport, export_memory(memory) -> dict. StrategyMemory is the persistent knowledge store for longitudinal insights. Integrates patterns, signals, and gap analyses."
        },
        "src/claire/recursive/longitudinal/recursive_quality_scorer.py": {
            "role": "Scores quality of recursive/longitudinal analysis",
            "content_spec": "Class RecursiveQualityScorer. Methods: score_run(run_data) -> QualityScore, compare_quality_trend(scores) -> TrendReport, detect_quality_regression(scores) -> list[Regression], compute_improvement_rate(scores) -> float, generate_quality_report(scores) -> QualityReport, export_scores(scores) -> dict. Writes quality scores to data/recursive/quality_scores/. Tracks pattern stability, signal noise ratio, gap closure rate."
        },
    },
},

# ──────────────────────────────────────────────────────────────────────────
#  PHASE 3: VALIDATION BENCHMARKS (v10.5)
#  Regime & signal backtesting, false positive/negative analysis,
#  outcome labeling, benchmark dataset management, benchmark reporting
# ──────────────────────────────────────────────────────────────────────────
{
    "phase": 3,
    "name": "Validation Benchmarks",
    "version": "v10.5",
    "description": "Regime and signal backtesting, false positive/negative analysis, outcome labeling, benchmark dataset management, reporting",
    "depends_on": [1, 2],
    "new_folders": [
        "src/claire/validation",
        "src/claire/validation/benchmarks",
        "data/validation/benchmark_datasets",
        "data/validation/benchmark_results",
        "data/validation/outcome_labels",
    ],
    "new_files": {
        "src/claire/validation/__init__.py": {
            "role": "Validation package init",
            "content_spec": "Package marker for claire.validation namespace. Exports benchmarks sub-package."
        },
        "src/claire/validation/benchmarks/__init__.py": {
            "role": "Benchmarks sub-package init",
            "content_spec": "Package marker. Exports: RegimeBacktester, SignalBacktester, FalsePositiveAnalyzer, FalseNegativeAnalyzer, OutcomeLabelManager, BenchmarkDatasetLoader, BenchmarkReporter"
        },
        "src/claire/validation/benchmarks/regime_backtester.py": {
            "role": "Backtests analysis against historical regime data",
            "content_spec": "Class RegimeBacktester. Methods: backtest(strategy, regime_data) -> BacktestResult, identify_regimes(historical_data) -> list[Regime], evaluate_regime_transitions(results) -> TransitionReport, compute_regime_accuracy(predictions, actuals) -> float, generate_equity_curve(results) -> list, export_backtest(result) -> dict. Regime represents a market/analytical state. Writes results to data/validation/benchmark_results/."
        },
        "src/claire/validation/benchmarks/signal_backtester.py": {
            "role": "Backtests individual signals against outcomes",
            "content_spec": "Class SignalBacktester. Methods: backtest_signal(signal_def, dataset) -> SignalBacktestResult, compute_hit_rate(results) -> float, compute_precision_recall(results) -> PrecisionRecall, analyze_signal_decay(results) -> DecayReport, compare_signals(results_a, results_b) -> ComparisonReport, export_results(results) -> dict. Tests signal predictive power across historical datasets. Writes to data/validation/benchmark_results/."
        },
        "src/claire/validation/benchmarks/false_positive_analyzer.py": {
            "role": "Analyzes false positive occurrences",
            "content_spec": "Class FalsePositiveAnalyzer. Methods: analyze(predictions, actuals) -> FPReport, classify_false_positive(fp) -> FPCategory, compute_fp_rate(predictions, actuals) -> float, identify_fp_clusters(fps) -> list[Cluster], suggest_threshold_adjustment(fps) -> ThresholdRecommendation, export_analysis(report) -> dict. FPCategory enum: NOISE, TIMING_ERROR, REGIME_MISMATCH, DATA_QUALITY, MODEL_OVERFIT. Logs to data/validation/benchmark_results/."
        },
        "src/claire/validation/benchmarks/false_negative_analyzer.py": {
            "role": "Analyzes false negative occurrences",
            "content_spec": "Class FalseNegativeAnalyzer. Methods: analyze(predictions, actuals) -> FNReport, classify_false_negative(fn) -> FNCategory, compute_fn_rate(predictions, actuals) -> float, identify_fn_patterns(fns) -> list[Pattern], compute_missed_opportunity_cost(fns) -> float, export_analysis(report) -> dict. FNCategory enum: SENSITIVITY_LOW, COVERAGE_GAP, TEMPORAL_LAG, FILTER_TOO_STRICT. Logs to data/validation/benchmark_results/."
        },
        "src/claire/validation/benchmarks/outcome_label_manager.py": {
            "role": "Manages ground-truth outcome labels for benchmarking",
            "content_spec": "Class OutcomeLabelManager. Methods: create_label(event_id, outcome) -> OutcomeLabel, update_label(label_id, new_outcome) -> OutcomeLabel, load_labels(dataset_id) -> list[OutcomeLabel], validate_labels(labels) -> ValidationResult, compute_label_coverage(labels, dataset) -> float, export_labels(labels) -> dict. Stores labels in data/validation/outcome_labels/. OutcomeLabel contains: event_id, label, confidence, labeled_by, labeled_at."
        },
        "src/claire/validation/benchmarks/benchmark_dataset_loader.py": {
            "role": "Loads and manages benchmark datasets",
            "content_spec": "Class BenchmarkDatasetLoader. Methods: load_dataset(dataset_id) -> BenchmarkDataset, list_datasets() -> list[DatasetMeta], validate_dataset(dataset) -> ValidationResult, split_dataset(dataset, ratio) -> tuple[Dataset, Dataset], compute_dataset_stats(dataset) -> DatasetStats, register_dataset(path, metadata) -> DatasetMeta. Reads from data/validation/benchmark_datasets/. Supports train/test splitting, cross-validation folds."
        },
        "src/claire/validation/benchmarks/benchmark_reporter.py": {
            "role": "Generates comprehensive benchmark reports",
            "content_spec": "Class BenchmarkReporter. Methods: generate_report(results, labels, dataset_meta) -> BenchmarkReport, format_summary(report) -> str, format_detailed(report) -> str, compare_runs(report_a, report_b) -> ComparisonReport, export_report(report, format) -> Path, compute_aggregate_metrics(reports) -> AggregateMetrics. Output formats: JSON, Markdown, HTML. Reads from data/validation/benchmark_results/."
        },
    },
},

# ──────────────────────────────────────────────────────────────────────────
#  PHASE 4: DESIGN PROOF & RENDERERS (v10.6)
#  Architecture feasibility, dependency risk, cost modeling, build
#  sequencing, deployment validation, maturity scoring, graph rendering
# ──────────────────────────────────────────────────────────────────────────
{
    "phase": 4,
    "name": "Design Proof & Renderers",
    "version": "v10.6",
    "description": "Architecture feasibility proofs, dependency risk analysis, cost modeling, build sequencing, deployment validation, design maturity scoring, graph formatting, blueprint export",
    "depends_on": [],
    "new_folders": [
        "src/claire/design",
        "src/claire/design/proof",
        "src/claire/design/renderers",
        "data/design/feasibility_reports",
        "data/design/dependency_risks",
        "data/design/cost_models",
        "data/design/build_sequences",
        "data/design/maturity_scores",
    ],
    "new_files": {
        "src/claire/design/__init__.py": {
            "role": "Design package init",
            "content_spec": "Package marker for claire.design namespace. Exports proof and renderers sub-packages."
        },
        "src/claire/design/proof/__init__.py": {
            "role": "Design proof sub-package init",
            "content_spec": "Package marker. Exports: ArchitectureFeasibilityProof, DependencyRiskProof, ImplementationCostModel, BuildSequenceValidator, DeploymentModelValidator, DesignMaturityScorer"
        },
        "src/claire/design/proof/architecture_feasibility_proof.py": {
            "role": "Proves feasibility of proposed architecture designs",
            "content_spec": "Class ArchitectureFeasibilityProof. Methods: prove_feasibility(architecture) -> FeasibilityVerdict, check_component_availability(components) -> AvailabilityReport, validate_integration_points(architecture) -> IntegrationReport, assess_scalability(architecture) -> ScalabilityAssessment, estimate_complexity(architecture) -> ComplexityScore, export_proof(verdict) -> dict. Writes feasibility reports to data/design/feasibility_reports/. FeasibilityVerdict: FEASIBLE, CONDITIONALLY_FEASIBLE, INFEASIBLE."
        },
        "src/claire/design/proof/dependency_risk_proof.py": {
            "role": "Analyzes and proves dependency risk levels",
            "content_spec": "Class DependencyRiskProof. Methods: analyze_risks(dependency_graph) -> RiskReport, identify_single_points_of_failure(graph) -> list, compute_coupling_score(graph) -> float, detect_circular_dependencies(graph) -> list, suggest_decoupling(risk) -> DecouplingPlan, export_risk_report(report) -> dict. Writes to data/design/dependency_risks/. RiskLevel enum: CRITICAL, HIGH, MEDIUM, LOW, NEGLIGIBLE."
        },
        "src/claire/design/proof/implementation_cost_model.py": {
            "role": "Models implementation costs for design decisions",
            "content_spec": "Class ImplementationCostModel. Methods: estimate_cost(design) -> CostEstimate, break_down_by_component(estimate) -> list[ComponentCost], compare_alternatives(designs) -> CostComparison, compute_roi(cost, projected_value) -> ROIReport, sensitivity_analysis(cost, variables) -> SensitivityReport, export_model(estimate) -> dict. Writes cost models to data/design/cost_models/. CostEstimate includes: effort_hours, complexity_factor, risk_premium, total_cost."
        },
        "src/claire/design/proof/build_sequence_validator.py": {
            "role": "Validates build sequences for dependency ordering",
            "content_spec": "Class BuildSequenceValidator. Methods: validate_sequence(sequence, dependency_graph) -> SequenceValidation, compute_optimal_order(graph) -> list[BuildStep], detect_ordering_violations(sequence) -> list[Violation], estimate_parallel_opportunities(sequence) -> ParallelPlan, generate_build_plan(graph) -> BuildPlan, export_sequence(plan) -> dict. Writes to data/design/build_sequences/. Topological sort with parallelism detection."
        },
        "src/claire/design/proof/deployment_model_validator.py": {
            "role": "Validates deployment models and configurations",
            "content_spec": "Class DeploymentModelValidator. Methods: validate_model(deployment_config) -> DeploymentValidation, check_resource_requirements(config) -> ResourceReport, validate_environment_compatibility(config, env) -> CompatibilityResult, assess_rollback_capability(config) -> RollbackAssessment, simulate_deployment(config) -> SimulationResult, export_validation(result) -> dict. Validates deployment configs against resource constraints and environment compatibility."
        },
        "src/claire/design/proof/design_maturity_scorer.py": {
            "role": "Scores design maturity across dimensions",
            "content_spec": "Class DesignMaturityScorer. Methods: score_maturity(design) -> MaturityScore, evaluate_completeness(design) -> float, evaluate_testability(design) -> float, evaluate_maintainability(design) -> float, evaluate_documentation(design) -> float, generate_maturity_report(scores) -> MaturityReport, export_scores(report) -> dict. Writes to data/design/maturity_scores/. MaturityLevel enum: INITIAL, DEVELOPING, DEFINED, MANAGED, OPTIMIZING."
        },
        "src/claire/design/renderers/__init__.py": {
            "role": "Design renderers sub-package init",
            "content_spec": "Package marker. Exports: ArchitectureGraphFormatter, DependencyGraphFormatter, DesignExportFormatter, BlueprintSummaryFormatter"
        },
        "src/claire/design/renderers/architecture_graph_formatter.py": {
            "role": "Formats architecture diagrams as structured graphs",
            "content_spec": "Class ArchitectureGraphFormatter. Methods: format_graph(architecture) -> FormattedGraph, render_component_diagram(components) -> str, render_layer_diagram(layers) -> str, apply_style(graph, style) -> FormattedGraph, export_svg(graph) -> str, export_mermaid(graph) -> str. Supports Mermaid, DOT, and SVG output formats. Renders component relationships, data flows, and layer boundaries."
        },
        "src/claire/design/renderers/dependency_graph_formatter.py": {
            "role": "Formats dependency graphs for visualization",
            "content_spec": "Class DependencyGraphFormatter. Methods: format_graph(dependencies) -> FormattedGraph, highlight_critical_path(graph) -> FormattedGraph, highlight_risks(graph, risk_report) -> FormattedGraph, render_tree_view(graph) -> str, export_dot(graph) -> str, export_mermaid(graph) -> str. Renders dependency trees with risk coloring, critical path highlighting, and cycle detection markers."
        },
        "src/claire/design/renderers/design_export_formatter.py": {
            "role": "Exports design artifacts in standard formats",
            "content_spec": "Class DesignExportFormatter. Methods: export_design(design, format) -> str, format_as_markdown(design) -> str, format_as_json(design) -> str, format_as_html(design) -> str, bundle_exports(designs) -> Path, validate_export(export) -> bool. Supported formats: JSON, Markdown, HTML. Bundles multiple design artifacts into a single export package."
        },
        "src/claire/design/renderers/blueprint_summary_formatter.py": {
            "role": "Generates blueprint summary documents",
            "content_spec": "Class BlueprintSummaryFormatter. Methods: format_summary(design, proofs, costs) -> BlueprintSummary, render_executive_view(summary) -> str, render_technical_view(summary) -> str, render_timeline_view(summary) -> str, export_summary(summary, format) -> Path, compare_blueprints(summary_a, summary_b) -> ComparisonView. BlueprintSummary aggregates feasibility, risk, cost, and maturity into a single decision document."
        },
    },
},

# ──────────────────────────────────────────────────────────────────────────
#  PHASE 5: TECHNOLOGY INTELLIGENCE (v10.7)
#  Compatibility engine, stack recommendation, integration complexity,
#  component matching, deployment assessment, technology cataloging
# ──────────────────────────────────────────────────────────────────────────
{
    "phase": 5,
    "name": "Technology Intelligence",
    "version": "v10.7",
    "description": "Technology compatibility engine, enterprise stack recommendation, integration complexity analysis, component matching, deployment assessment, technology cataloging, dependency mapping, model governance",
    "depends_on": [4],
    "new_folders": [
        "src/claire/technology",
        "data/technology/compatibility_reports",
        "data/technology/stack_recommendations",
        "data/technology/integration_assessments",
    ],
    "new_files": {
        "src/claire/technology/__init__.py": {
            "role": "Technology package init",
            "content_spec": "Package marker for claire.technology namespace. Exports: CompatibilityEngine, EnterpriseStackRecommender, IntegrationComplexity, ComponentMatcher, DeploymentAssessor, TechnologyCatalog, DependencyMapper, ModelGovernanceAssessor"
        },
        "src/claire/technology/compatibility_engine.py": {
            "role": "Evaluates technology compatibility across stack",
            "content_spec": "Class CompatibilityEngine. Methods: check_compatibility(tech_a, tech_b) -> CompatibilityResult, evaluate_stack_compatibility(stack) -> StackCompatReport, detect_version_conflicts(stack) -> list[Conflict], suggest_compatible_alternatives(tech, stack) -> list[Alternative], compute_compatibility_matrix(technologies) -> Matrix, export_report(report) -> dict. Writes compatibility reports to data/technology/compatibility_reports/."
        },
        "src/claire/technology/enterprise_stack_recommender.py": {
            "role": "Recommends enterprise technology stacks",
            "content_spec": "Class EnterpriseStackRecommender. Methods: recommend_stack(requirements) -> StackRecommendation, evaluate_stack_fit(stack, requirements) -> FitScore, compare_stacks(stack_a, stack_b) -> StackComparison, assess_migration_path(current, target) -> MigrationPlan, compute_tco(stack, horizon_years) -> TCOEstimate, export_recommendation(rec) -> dict. Writes recommendations to data/technology/stack_recommendations/."
        },
        "src/claire/technology/integration_complexity.py": {
            "role": "Assesses integration complexity between components",
            "content_spec": "Class IntegrationComplexity. Methods: assess_complexity(component_a, component_b) -> ComplexityScore, map_integration_points(system) -> list[IntegrationPoint], estimate_integration_effort(points) -> EffortEstimate, identify_integration_risks(points) -> list[Risk], rank_by_complexity(integrations) -> list, export_assessment(assessment) -> dict. Writes to data/technology/integration_assessments/. ComplexityLevel enum: TRIVIAL, LOW, MODERATE, HIGH, EXTREME."
        },
        "src/claire/technology/component_matcher.py": {
            "role": "Matches technology components to requirements",
            "content_spec": "Class ComponentMatcher. Methods: match_components(requirements) -> list[ComponentMatch], score_match(component, requirement) -> float, find_alternatives(component) -> list[Alternative], compare_components(comp_a, comp_b) -> ComparisonReport, validate_match(match, constraints) -> ValidationResult, export_matches(matches) -> dict. Uses technology catalog for component discovery. Scoring based on functional fit, maturity, community support, licensing."
        },
        "src/claire/technology/deployment_assessor.py": {
            "role": "Assesses deployment readiness and requirements",
            "content_spec": "Class DeploymentAssessor. Methods: assess_readiness(system, environment) -> ReadinessReport, check_infrastructure_requirements(system) -> InfraRequirements, evaluate_monitoring_coverage(system) -> CoverageReport, assess_security_posture(system) -> SecurityAssessment, estimate_deployment_risk(system) -> RiskScore, export_assessment(report) -> dict. Evaluates infrastructure, monitoring, security, and operational readiness."
        },
        "src/claire/technology/technology_catalog.py": {
            "role": "Maintains catalog of known technologies",
            "content_spec": "Class TechnologyCatalog. Methods: register_technology(tech_meta) -> TechEntry, search_catalog(query) -> list[TechEntry], get_technology(tech_id) -> TechEntry, update_technology(tech_id, updates) -> TechEntry, list_by_category(category) -> list[TechEntry], export_catalog() -> dict. TechEntry contains: tech_id, name, version, category, license, maturity, supported_platforms, integration_apis."
        },
        "src/claire/technology/dependency_mapper.py": {
            "role": "Maps technology dependencies across the system",
            "content_spec": "Class DependencyMapper. Methods: map_dependencies(system) -> DependencyGraph, detect_transitive_deps(graph) -> list, compute_depth(graph) -> int, identify_bottlenecks(graph) -> list[Bottleneck], visualize_graph(graph) -> str, export_map(graph) -> dict. Builds complete dependency graph including transitive dependencies. Identifies version pinning issues and upgrade cascades."
        },
        "src/claire/technology/model_governance_assessor.py": {
            "role": "Assesses governance requirements for AI/ML models",
            "content_spec": "Class ModelGovernanceAssessor. Methods: assess_governance(model_meta) -> GovernanceReport, check_bias_risk(model) -> BiasRiskScore, evaluate_explainability(model) -> ExplainabilityScore, assess_data_lineage(model) -> LineageReport, check_compliance(model, regulations) -> ComplianceReport, export_assessment(report) -> dict. Evaluates model governance across bias, explainability, data lineage, compliance, and auditability dimensions."
        },
    },
},

# ──────────────────────────────────────────────────────────────────────────
#  PHASE 6: AUTONOMOUS GOVERNANCE (v10.8)
#  Action policy, self-change permissions, decision auditing, escalation
#  boundaries, human review gates, autonomy maturity scoring
# ──────────────────────────────────────────────────────────────────────────
{
    "phase": 6,
    "name": "Autonomous Governance",
    "version": "v10.8",
    "description": "Autonomous action policy, self-change permission model, decision auditing, escalation boundaries, human review gates, autonomy maturity scoring",
    "depends_on": [1, 2, 3, 4, 5],
    "new_folders": [
        "src/claire/autonomous",
        "src/claire/autonomous/governance",
        "data/autonomous/action_logs",
        "data/autonomous/permission_grants",
        "data/autonomous/audit_trails",
        "data/autonomous/escalation_history",
    ],
    "new_files": {
        "src/claire/autonomous/__init__.py": {
            "role": "Autonomous package init",
            "content_spec": "Package marker for claire.autonomous namespace. Exports governance sub-package."
        },
        "src/claire/autonomous/governance/__init__.py": {
            "role": "Governance sub-package init",
            "content_spec": "Package marker. Exports: AutonomousActionPolicy, SelfChangePermissionModel, AutonomousDecisionAuditor, EscalationBoundary, HumanReviewGate, AutonomyMaturityScorer"
        },
        "src/claire/autonomous/governance/autonomous_action_policy.py": {
            "role": "Defines and enforces autonomous action policies",
            "content_spec": "Class AutonomousActionPolicy. Methods: evaluate_action(action_request) -> PolicyDecision, load_policy(policy_path) -> Policy, check_permissions(action, context) -> PermissionResult, enforce_rate_limits(action) -> RateLimitResult, log_action(action, decision) -> None, export_policy(policy) -> dict. PolicyDecision enum: ALLOW, DENY, ESCALATE, DEFER. Logs all decisions to data/autonomous/action_logs/. Every autonomous action must pass through this gate."
        },
        "src/claire/autonomous/governance/self_change_permission_model.py": {
            "role": "Controls permissions for self-modification actions",
            "content_spec": "Class SelfChangePermissionModel. Methods: request_permission(change_type, scope) -> PermissionGrant, validate_change(change, grant) -> ValidationResult, check_scope_limits(change) -> ScopeCheck, revoke_permission(grant_id) -> None, list_active_grants() -> list[PermissionGrant], export_grants() -> dict. ChangeType enum: CONFIG_UPDATE, CODE_MODIFY, DATA_MUTATE, POLICY_CHANGE, ARCHITECTURE_ALTER. Writes grants to data/autonomous/permission_grants/. All self-modifications require explicit permission grants."
        },
        "src/claire/autonomous/governance/autonomous_decision_auditor.py": {
            "role": "Audits autonomous decisions for compliance",
            "content_spec": "Class AutonomousDecisionAuditor. Methods: audit_decision(decision_record) -> AuditResult, review_decision_chain(decisions) -> ChainAudit, detect_policy_violations(decisions) -> list[Violation], compute_autonomy_metrics(audit_period) -> AutonomyMetrics, generate_audit_report(period) -> AuditReport, export_audit(report) -> dict. Writes audit trails to data/autonomous/audit_trails/. Tracks decision quality, policy compliance, and escalation appropriateness."
        },
        "src/claire/autonomous/governance/escalation_boundary.py": {
            "role": "Defines boundaries that trigger human escalation",
            "content_spec": "Class EscalationBoundary. Methods: check_boundary(action, context) -> BoundaryResult, define_boundary(name, conditions) -> Boundary, evaluate_risk_threshold(action) -> RiskLevel, trigger_escalation(action, reason) -> EscalationRecord, list_boundaries() -> list[Boundary], export_boundaries() -> dict. BoundaryResult: WITHIN_BOUNDS, APPROACHING_BOUNDARY, BOUNDARY_CROSSED. Writes escalation records to data/autonomous/escalation_history/."
        },
        "src/claire/autonomous/governance/human_review_gate.py": {
            "role": "Gates requiring human review before execution",
            "content_spec": "Class HumanReviewGate. Methods: submit_for_review(action, context) -> ReviewRequest, check_review_status(request_id) -> ReviewStatus, approve_action(request_id, reviewer) -> ApprovalResult, reject_action(request_id, reviewer, reason) -> RejectionResult, list_pending_reviews() -> list[ReviewRequest], export_review_log() -> dict. ReviewStatus enum: PENDING, APPROVED, REJECTED, EXPIRED, WITHDRAWN. Integrates with escalation boundary for automatic gate triggering."
        },
        "src/claire/autonomous/governance/autonomy_maturity_scorer.py": {
            "role": "Scores the maturity of autonomous operations",
            "content_spec": "Class AutonomyMaturityScorer. Methods: score_maturity(governance_data) -> MaturityScore, evaluate_policy_coverage(policies) -> float, evaluate_audit_completeness(audits) -> float, evaluate_escalation_effectiveness(escalations) -> float, evaluate_human_oversight_balance(reviews) -> float, generate_maturity_report(scores) -> MaturityReport, export_scores(report) -> dict. AutonomyLevel enum: SUPERVISED, SEMI_AUTONOMOUS, CONDITIONALLY_AUTONOMOUS, HIGHLY_AUTONOMOUS, FULLY_GOVERNED. Assesses readiness to increase autonomy levels."
        },
    },
},

]  # END PHASES

# ============================================================================
#  CONTENT GENERATION ENGINE
# ============================================================================

def create_file_content(rel_path, spec):
    """Generate file content based on path extension and content_spec."""
    ext = Path(rel_path).suffix
    name = Path(rel_path).stem
    role = spec.get("role", "")
    content_spec = spec.get("content_spec", "")

    if ext == ".py":
        return _generate_python_file(rel_path, name, role, content_spec)
    elif ext == ".json":
        return _generate_json_file(rel_path, name, role, content_spec)
    else:
        return f"# {role}\n# {content_spec}\n"


def _generate_python_file(rel_path, name, role, content_spec):
    """Generate a governed Python source file with class/method stubs."""
    module_path = rel_path.replace("/", ".").replace("\\", ".").rstrip(".py")

    # Determine if this is an __init__.py (package marker)
    if name == "__init__":
        return _generate_init_file(rel_path, role, content_spec)

    # Parse class name and methods from content_spec
    class_name = None
    methods = []
    enums = []

    if "Class " in content_spec:
        # Extract class name
        class_start = content_spec.index("Class ") + 6
        class_end = content_spec.index(".", class_start)
        class_name = content_spec[class_start:class_end]

    if "Methods: " in content_spec:
        methods_str = content_spec.split("Methods: ")[1].split(". ")[0]
        for m in methods_str.split(", "):
            m = m.strip()
            if m:
                methods.append(m)

    if " enum: " in content_spec.lower():
        for part in content_spec.split(". "):
            if " enum: " in part.lower():
                enums.append(part.strip())

    lines = []
    lines.append(f'"""')
    lines.append(f"{role}")
    lines.append(f"{'=' * len(role)}")
    lines.append(f"ACS2-Claire / Syntalion")
    lines.append(f"")
    lines.append(f"Module: {module_path}")
    lines.append(f"Role: {role}")
    lines.append(f'"""')
    lines.append(f"")
    lines.append(f"import json")
    lines.append(f"import logging")
    lines.append(f"from datetime import datetime")
    lines.append(f"from pathlib import Path")
    lines.append(f"from dataclasses import dataclass, field")
    lines.append(f"from typing import Any, Optional")
    if enums:
        lines.append(f"from enum import Enum")
    lines.append(f"")
    lines.append(f'logger = logging.getLogger(__name__)')
    lines.append(f"")

    # Generate enums
    for enum_str in enums:
        parts = enum_str.split(" enum: ")
        if len(parts) == 2:
            enum_name_raw = parts[0].strip().split()[-1]
            enum_values = [v.strip() for v in parts[1].split(",")]
            lines.append(f"")
            lines.append(f"class {enum_name_raw}(Enum):")
            for val in enum_values:
                val_clean = val.strip().rstrip(".")
                if val_clean:
                    lines.append(f'    {val_clean} = "{val_clean.lower()}"')
            lines.append(f"")

    # Generate class
    if class_name:
        lines.append(f"")
        lines.append(f"class {class_name}:")
        lines.append(f'    """')
        lines.append(f"    {role}")
        lines.append(f"")

        # Add description from content_spec (after methods)
        desc_parts = content_spec.split(". ")
        for dp in desc_parts:
            dp = dp.strip()
            if dp and not dp.startswith("Class ") and not dp.startswith("Methods:") and "enum:" not in dp.lower():
                lines.append(f"    {dp}.")
        lines.append(f'    """')
        lines.append(f"")
        lines.append(f"    def __init__(self):")
        lines.append(f"        self.logger = logging.getLogger(self.__class__.__name__)")
        lines.append(f'        self.logger.info(f"{{self.__class__.__name__}} initialized")')
        lines.append(f"")

        # Generate method stubs
        for method_sig in methods:
            method_sig = method_sig.strip()
            if not method_sig:
                continue
            # Clean up the signature
            if "->" in method_sig:
                m_name_args, m_return = method_sig.split("->", 1)
                m_return = m_return.strip()
            else:
                m_name_args = method_sig
                m_return = "Any"

            m_name_args = m_name_args.strip()

            lines.append(f"    def {m_name_args}:")
            lines.append(f'        """Returns {m_return}."""')
            lines.append(f"        raise NotImplementedError")
            lines.append(f"")
    else:
        lines.append(f"# Content spec: {content_spec}")

    return "\n".join(lines) + "\n"


def _generate_init_file(rel_path, role, content_spec):
    """Generate a package __init__.py with exports."""
    pkg_path = Path(rel_path).parent
    module_path = str(pkg_path).replace("/", ".").replace("\\", ".")

    lines = []
    lines.append(f'"""')
    lines.append(f"{role}")
    lines.append(f"{'=' * len(role)}")
    lines.append(f"ACS2-Claire / Syntalion")
    lines.append(f"")
    lines.append(f"Package: {module_path}")
    lines.append(f'"""')
    lines.append(f"")

    # Parse exports from content_spec
    if "Exports:" in content_spec:
        exports_str = content_spec.split("Exports:")[1].strip()
        exports = [e.strip() for e in exports_str.split(",")]
        lines.append(f"__all__ = [")
        for exp in exports:
            exp = exp.strip().rstrip(".")
            if exp:
                lines.append(f'    "{exp}",')
        lines.append(f"]")
    elif "Exports " in content_spec:
        exports_str = content_spec.split("Exports ")[1].strip()
        exports = [e.strip().rstrip(".") for e in exports_str.replace(" and ", ", ").split(",")]
        lines.append(f"__all__ = [")
        for exp in exports:
            exp = exp.strip()
            if exp:
                lines.append(f'    "{exp}",')
        lines.append(f"]")

    lines.append(f"")
    return "\n".join(lines) + "\n"


def _generate_json_file(rel_path, name, role, content_spec):
    """Generate a JSON template file."""
    return json.dumps({
        "_meta": {
            "role": role,
            "spec": content_spec,
            "generated_by": f"claire_installer_v{INSTALLER_VERSION}",
            "generated_at": datetime.now().isoformat(),
        }
    }, indent=2) + "\n"


# ============================================================================
#  PREFLIGHT CHECK
# ============================================================================

def preflight_check(target: Path) -> bool:
    """Verify target directory is a valid Claire project."""
    checks = {
        "target_exists": target.is_dir(),
        "has_src": (target / "src").is_dir(),
        "has_version_json": (target / "version.json").is_file(),
        "has_main": (target / "main.py").is_file(),
    }

    print("\n  Preflight checks:")
    all_ok = True
    for check, passed in checks.items():
        status = "✓" if passed else "✗"
        print(f"    [{status}] {check}")
        if not passed:
            all_ok = False

    if not all_ok:
        print("\n  ⚠  Some checks failed. Use --target to specify project root.")
        print(f"  Expected: {target}")

    return all_ok


# ============================================================================
#  INSTALL PHASE
# ============================================================================

def install_phase(phase_def: dict, target: Path, dry_run: bool = False) -> dict:
    """Install a single phase: create folders, generate and write files."""
    phase_num = phase_def["phase"]
    phase_name = phase_def["name"]
    phase_ver = phase_def["version"]

    result = {
        "phase": phase_num,
        "name": phase_name,
        "version": phase_ver,
        "folders_created": [],
        "files_created": [],
        "files_skipped": [],
        "errors": [],
    }

    print(f"\n  ── Phase {phase_num}: {phase_name} ({phase_ver}) ──")

    # Create folders
    for folder in phase_def.get("new_folders", []):
        folder_path = target / folder
        if dry_run:
            tag = "EXISTS" if folder_path.is_dir() else "NEW"
            print(f"    [DIR]  {folder}  ({tag})")
            result["folders_created"].append(folder)
        else:
            try:
                folder_path.mkdir(parents=True, exist_ok=True)
                # Create .gitkeep for data directories
                if folder.startswith("data/"):
                    gitkeep = folder_path / ".gitkeep"
                    if not gitkeep.exists():
                        gitkeep.touch()
                print(f"    [DIR]  ✓ {folder}")
                result["folders_created"].append(folder)
            except Exception as e:
                print(f"    [DIR]  ✗ {folder}: {e}")
                result["errors"].append(f"folder:{folder}:{e}")

    # Create files
    for rel_path, spec in phase_def.get("new_files", {}).items():
        file_path = target / rel_path
        if file_path.exists():
            print(f"    [FILE] ⊘ {rel_path}  (already exists, skipped)")
            result["files_skipped"].append(rel_path)
            continue

        if dry_run:
            print(f"    [FILE] {rel_path}  ({spec.get('role', '')})")
            result["files_created"].append(rel_path)
        else:
            try:
                file_path.parent.mkdir(parents=True, exist_ok=True)
                content = create_file_content(rel_path, spec)
                file_path.write_text(content, encoding="utf-8")
                print(f"    [FILE] ✓ {rel_path}")
                result["files_created"].append(rel_path)
            except Exception as e:
                print(f"    [FILE] ✗ {rel_path}: {e}")
                result["errors"].append(f"file:{rel_path}:{e}")

    # Summary
    fc = len(result["files_created"])
    fs = len(result["files_skipped"])
    dc = len(result["folders_created"])
    ec = len(result["errors"])
    mode = "DRY RUN" if dry_run else "INSTALLED"
    print(f"\n    {mode}: {dc} folders, {fc} files created, {fs} skipped, {ec} errors")

    return result


# ============================================================================
#  AUDIT LOG
# ============================================================================

def write_audit_log(target: Path, results: list, dry_run: bool = False):
    """Write installation audit log."""
    if dry_run:
        return

    log_dir = target / "data" / "update_logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"install_{timestamp}_adv_{INSTALLER_ID}.json"

    audit = {
        "installer_version": INSTALLER_VERSION,
        "installer_id": INSTALLER_ID,
        "installer_date": INSTALLER_DATE,
        "install_timestamp": datetime.now().isoformat(),
        "target_path": str(target),
        "phases_installed": len(results),
        "total_folders": sum(len(r["folders_created"]) for r in results),
        "total_files_created": sum(len(r["files_created"]) for r in results),
        "total_files_skipped": sum(len(r["files_skipped"]) for r in results),
        "total_errors": sum(len(r["errors"]) for r in results),
        "phase_results": results,
    }

    log_path.write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(f"\n  Audit log: {log_path}")


# ============================================================================
#  SUMMARY DISPLAY
# ============================================================================

def show_summary():
    """Display installer summary without installing."""
    total_files = sum(len(p["new_files"]) for p in PHASES)
    total_folders = sum(len(p["new_folders"]) for p in PHASES)

    print(f"\n{'=' * 64}")
    print(f"  Claire v{INSTALLER_VERSION} — Advanced Subsystems Installer")
    print(f"  ACS2-Claire / Syntalion")
    print(f"  Date: {INSTALLER_DATE}  |  ID: {INSTALLER_ID}")
    print(f"{'=' * 64}")
    print(f"\n  Total: {len(PHASES)} phases, {total_files} files, {total_folders} folders\n")

    for p in PHASES:
        nf = len(p["new_files"])
        nd = len(p["new_folders"])
        deps = ", ".join(str(d) for d in p["depends_on"]) if p["depends_on"] else "none"
        print(f"  Phase {p['phase']}: {p['name']} ({p['version']})")
        print(f"    {p['description']}")
        print(f"    {nf} files, {nd} folders | depends on: {deps}")
        print()

    print(f"  New source packages:")
    src_folders = sorted(set(
        f for p in PHASES for f in p["new_folders"] if f.startswith("src/")
    ))
    for f in src_folders:
        print(f"    {f}/")

    print(f"\n  New data directories:")
    data_folders = sorted(set(
        f for p in PHASES for f in p["new_folders"] if f.startswith("data/")
    ))
    for f in data_folders:
        print(f"    {f}/")

    print()


# ============================================================================
#  MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description=f"Claire v{INSTALLER_VERSION} Advanced Subsystems Installer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                       Show what would be installed (dry run)
  %(prog)s --install              Install all 6 phases
  %(prog)s --install --phase 3    Install only phase 3 (Validation Benchmarks)
  %(prog)s --target ./Claire      Use custom project path
  %(prog)s --summary              Show phase summary
        """,
    )
    parser.add_argument("--install", action="store_true",
                        help="Actually install (default is dry run)")
    parser.add_argument("--phase", type=int, choices=[1, 2, 3, 4, 5, 6],
                        help="Install only this phase (1-6)")
    parser.add_argument("--target", type=str, default=DEFAULT_TARGET,
                        help=f"Project root (default: {DEFAULT_TARGET})")
    parser.add_argument("--summary", action="store_true",
                        help="Show installer summary and exit")
    args = parser.parse_args()

    target = Path(args.target).resolve()
    dry_run = not args.install

    # Header
    print(f"\n{'═' * 64}")
    print(f"  Claire v{INSTALLER_VERSION} — Advanced Subsystems Installer")
    print(f"  ACS2-Claire / Syntalion")
    print(f"  Date: {INSTALLER_DATE}  |  ID: {INSTALLER_ID}")
    print(f"  Target: {target}")
    print(f"  Mode: {'INSTALL' if not dry_run else 'DRY RUN (use --install to apply)'}")
    print(f"{'═' * 64}")

    if args.summary:
        show_summary()
        return

    # Preflight
    if not preflight_check(target):
        if not args.install:
            print("\n  (Dry run — preflight warnings are informational)")
        else:
            print("\n  ✗ Aborting install due to failed preflight checks.")
            print("    Use --target to specify the correct project root.")
            sys.exit(1)

    # Select phases
    if args.phase:
        phases_to_install = [p for p in PHASES if p["phase"] == args.phase]
    else:
        phases_to_install = PHASES

    # Check dependencies
    installed_phases = set()
    for p in phases_to_install:
        for dep in p["depends_on"]:
            if dep not in installed_phases and dep not in [pp["phase"] for pp in phases_to_install]:
                print(f"\n  ⚠  Phase {p['phase']} depends on phase {dep}.")
                if args.phase:
                    print(f"     Ensure phase {dep} is already installed.")

        installed_phases.add(p["phase"])

    # Install
    results = []
    for phase_def in phases_to_install:
        result = install_phase(phase_def, target, dry_run)
        results.append(result)

    # Audit log
    write_audit_log(target, results, dry_run)

    # Final summary
    total_fc = sum(len(r["files_created"]) for r in results)
    total_fs = sum(len(r["files_skipped"]) for r in results)
    total_dc = sum(len(r["folders_created"]) for r in results)
    total_ec = sum(len(r["errors"]) for r in results)

    print(f"\n{'═' * 64}")
    print(f"  {'DRY RUN COMPLETE' if dry_run else 'INSTALLATION COMPLETE'}")
    print(f"  {len(results)} phases | {total_dc} folders | {total_fc} files | {total_fs} skipped | {total_ec} errors")
    if dry_run:
        print(f"\n  To install for real, run with --install")
    print(f"{'═' * 64}\n")


if __name__ == "__main__":
    main()
