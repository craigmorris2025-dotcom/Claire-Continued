#!/usr/bin/env python3
"""
Claire v10.3.1 Evolution & Update Governance Installer
======================================================
ACS2-Claire / Syntalion — v10.3.0 → v10.3.1

Two new governed subsystems:
  1. Evolution Layer     — Project identity, verified state, regression guard,
                           forward motion policy, evolution memory
  2. Update Governance   — Authority-gated, inspected, staged, signed, validated,
                           rollback-safe update pipeline

Plus: API route, frontend panels, and governed data directories.

USAGE:
  python claire_v10.3.1_evolution_governance_installer.py                     # Dry run
  python claire_v10.3.1_evolution_governance_installer.py --install            # Install all
  python claire_v10.3.1_evolution_governance_installer.py --install --phase 1  # Single phase
  python claire_v10.3.1_evolution_governance_installer.py --target ./Claire    # Custom path

BASE PATH: C:\\Users\\craig\\OneDrive\\Desktop\\Claire\\
"""

import os, sys, json, argparse, hashlib
from datetime import datetime
from pathlib import Path

# ============================================================================
#  CONFIGURATION
# ============================================================================

DEFAULT_TARGET = os.path.expanduser("~/OneDrive/Desktop/Claire")
INSTALLER_VERSION = "10.3.1"
INSTALLER_DATE = "2026-05-06"
INSTALLER_ID = hashlib.md5(f"claire_evo_gov_{INSTALLER_DATE}".encode()).hexdigest()[:12]

# ============================================================================
#  PHASE DEFINITIONS — 4 PHASES, 34 NEW FILES, 21 NEW FOLDERS
# ============================================================================

PHASES = [

# ──────────────────────────────────────────────────────────────────────────
#  PHASE 1: EVOLUTION LAYER
#  Claire's self-awareness — who she is, where she's been, where she's going
# ──────────────────────────────────────────────────────────────────────────
{
    "phase": 1,
    "name": "Evolution Layer",
    "version": "v10.3.1-phase1",
    "description": "Project identity, verified state tracking, regression prevention, forward motion governance, evolution memory",
    "depends_on": [],
    "new_folders": [
        "src/claire/evolution",
    ],
    "new_files": {
        "src/claire/evolution/__init__.py": {
            "role": "Evolution layer package init",
            "content_spec": "Package marker. Exports: ProjectIdentity, MasterDocumentRegistry, VersionTimeline, TargetState, CapabilityRegistry, VerifiedStateStore, RegressionGuard, ForwardMotionPolicy, EvolutionMemory, EvolutionOrchestrator"
        },
        "src/claire/evolution/project_identity.py": {
            "role": "Claire's canonical self-definition — who she IS",
            "content_spec": "Loads and enforces Claire's identity from governing documents. Fields: system_name, codename, owner, mission_statement, core_principles (7), identity_hash. Methods: validate_identity() — confirms current state matches governing docs. get_identity_summary() — returns canonical identity block. identity_drift_check() — detects if runtime behavior contradicts identity. Reads from data/evolution/identity/. Immutable once loaded — no runtime modification allowed."
        },
        "src/claire/evolution/master_document_registry.py": {
            "role": "Registry of all governing documents — single source of document authority",
            "content_spec": "Tracks every governing document (Master Build Plan, Singularity Edition, File Manifest, etc.) with: document_id, title, version, hash, authority_level (constitutional/governing/operational/reference), last_verified_date. Methods: register_document(), verify_document_integrity(), get_authority_chain(), detect_conflicts() — finds contradictions between governing docs. Stored in data/evolution/origin/."
        },
        "src/claire/evolution/version_timeline.py": {
            "role": "Complete version history — every version, what it delivered, proof of completion",
            "content_spec": "Canonical timeline from v1.0 through v10.2 (and forward). Per-version record: version, codename, date_completed, stages_implemented, modules_added, files_added, test_results, validation_scores, proof_artifacts. Methods: get_timeline(), get_version_detail(v), verify_version_proof(v), get_current_version(), get_next_target(). Reads/writes data/evolution/timeline/."
        },
        "src/claire/evolution/target_state.py": {
            "role": "Defines where Claire is GOING — the target completion state",
            "content_spec": "Loads target state definition from governing documents. Fields: target_version, required_capabilities (list), required_stages (1-30), required_routes (portfolio/breakthrough/acquisition/system/operational/business-model), required_loops (8 ACS2), required_memory_functions (5), completion_criteria. Methods: get_target(), get_gap_to_target(), is_target_reached(), get_completion_percentage(). Reads from data/evolution/target_state/."
        },
        "src/claire/evolution/capability_registry.py": {
            "role": "Registry of every capability Claire has — verified, not assumed",
            "content_spec": "Tracks capabilities with evidence. Per-capability: capability_id, name, category (signal/lifecycle/route/breakthrough/tech/acquisition/loop/memory/autonomous/system), status (not_started/structural/partial/operational/mature), evidence (list of proof artifacts), last_verified, verification_method. Methods: register_capability(), verify_capability(), get_all_by_status(), get_capability_matrix(), snapshot() — saves to data/evolution/capability_snapshots/."
        },
        "src/claire/evolution/verified_state_store.py": {
            "role": "Immutable store of verified system states — what has been PROVEN to work",
            "content_spec": "Stores verified state snapshots: state_id, timestamp, version, capabilities_verified (list), test_results, validation_scores, evidence_hashes, verified_by. Methods: record_verified_state(), get_latest_verified(), get_state_at_version(v), compare_states(a, b), verify_state_integrity(). Append-only — states cannot be modified or deleted. Writes to data/evolution/verified_states/."
        },
        "src/claire/evolution/regression_guard.py": {
            "role": "Prevents capability regression — nothing verified can be lost",
            "content_spec": "Before any system change: checks that all previously verified capabilities still pass. Methods: pre_change_snapshot(), post_change_verify(), detect_regressions(), generate_regression_report(), block_if_regression() — hard-blocks changes that break verified capabilities. Regression report format: capability, expected_status, actual_status, evidence_diff, severity. Writes to data/evolution/regression_reports/."
        },
        "src/claire/evolution/forward_motion_policy.py": {
            "role": "Governs what constitutes valid forward motion — prevents sideways drift",
            "content_spec": "Defines rules for what counts as progress vs. drift. Methods: evaluate_change(proposed_change) — returns (is_forward, reasoning, impact_score). is_aligned_with_target(change) — checks against target_state. detect_drift() — identifies when recent changes aren't moving toward target. get_forward_velocity() — measures rate of progress. Decision logged to data/evolution/forward_decisions/."
        },
        "src/claire/evolution/evolution_memory.py": {
            "role": "Long-term memory of how Claire has evolved — learns from its own evolution",
            "content_spec": "Tracks: decisions_made (and their outcomes), approaches_tried (and success/failure), architectural_lessons, capability_build_patterns, time_to_completion_by_type. Methods: record_evolution_event(), query_memory(topic), get_lessons_for(capability_type), get_build_velocity_trend(), get_failure_patterns(). Reads/writes data/evolution/completion_memory/."
        },
        "src/claire/evolution/evolution_orchestrator.py": {
            "role": "Master orchestrator — coordinates all evolution subsystems",
            "content_spec": "Coordinates: project_identity, master_document_registry, version_timeline, target_state, capability_registry, verified_state_store, regression_guard, forward_motion_policy, evolution_memory. Methods: get_system_status() — full evolution status report, propose_change(change) — runs through regression guard + forward motion + target alignment, execute_change(change) — governed change execution, get_evolution_dashboard_data() — data for frontend panel. Entry point for all evolution operations."
        },
    }
},

# ──────────────────────────────────────────────────────────────────────────
#  PHASE 2: UPDATE GOVERNANCE LAYER
#  No update enters the system without inspection, staging, validation,
#  and rollback readiness
# ──────────────────────────────────────────────────────────────────────────
{
    "phase": 2,
    "name": "Update Governance Layer",
    "version": "v10.3.1-phase2",
    "description": "Authority-gated, inspected, staged, signed, validated, rollback-safe update pipeline",
    "depends_on": [1],
    "new_folders": [
        "src/claire/platform/update_governance",
    ],
    "new_files": {
        "src/claire/platform/update_governance/__init__.py": {
            "role": "Update governance package init",
            "content_spec": "Package marker. Exports all 18 governance modules."
        },
        "src/claire/platform/update_governance/authority_map.py": {
            "role": "Defines WHO can authorize updates and WHAT they can touch",
            "content_spec": "Authority levels: owner (Craig), system (Claire self-update), external (third-party). Per-authority: allowed_paths, denied_paths, requires_approval, max_change_scope. Methods: check_authority(source, target_path) — returns (authorized, reason). get_authority_for_path(path). Protected paths: lifecycle/, governance/, safety/, evolution/ require owner authority. Reads from data/update_governance/approvals/."
        },
        "src/claire/platform/update_governance/package_inspector.py": {
            "role": "Inspects incoming update packages BEFORE any installation",
            "content_spec": "Inspection checks: file_count, file_types, size_analysis, path_analysis (where files want to go), conflict_detection (files that already exist), suspicious_pattern_detection (unexpected executables, oversized files, path traversal). Methods: inspect_package(package_path) — returns InspectionReport. quarantine_if_suspicious(). Reports written to data/update_governance/inspected/."
        },
        "src/claire/platform/update_governance/source_trust.py": {
            "role": "Trust scoring for update sources — not all sources are equal",
            "content_spec": "Trust levels: verified (owner-produced), trusted (known CI/CD), unknown (first-time source), untrusted (failed previous validation). Methods: evaluate_source(source_id) — returns trust_score. register_source(). update_trust_after_outcome(). get_trusted_sources(). Source history tracked in data/update_governance/signatures/."
        },
        "src/claire/platform/update_governance/signature_verifier.py": {
            "role": "Cryptographic signature verification for update packages",
            "content_spec": "Verifies: SHA-256 checksums per file, package-level signature, source signature chain. Methods: verify_package_signature(package, expected_sig), generate_signature(package), verify_file_integrity(file_path, expected_hash), sign_package(package). Keys and signatures stored in data/update_governance/signatures/."
        },
        "src/claire/platform/update_governance/dependency_impact_analyzer.py": {
            "role": "Analyzes what an update will AFFECT across the system",
            "content_spec": "Traces dependency graph from changed files: which modules import them, which stages use those modules, which routes are affected, which tests cover them. Methods: analyze_impact(changed_files) — returns ImpactReport with affected_modules, affected_stages, affected_routes, affected_tests, risk_score. get_dependency_graph(module). Reports to data/update_governance/reports/."
        },
        "src/claire/platform/update_governance/capability_diff.py": {
            "role": "Diffs capabilities before and after an update — what changes?",
            "content_spec": "Takes pre-update capability snapshot and post-update snapshot. Methods: diff_capabilities(before, after) — returns CapabilityDiff with added, removed, modified, unchanged, degraded. detect_unintended_changes(). verify_no_capability_loss(). Works with evolution/capability_registry."
        },
        "src/claire/platform/update_governance/lifecycle_stage_impact.py": {
            "role": "Assesses which lifecycle stages (1-30) an update will affect",
            "content_spec": "Maps changed files to lifecycle stages. Methods: get_affected_stages(changed_files) — returns list of (stage_number, stage_name, impact_severity). requires_stage_revalidation(stage) — checks if stage contracts need re-verification. get_stage_dependency_chain(stage) — downstream stages affected."
        },
        "src/claire/platform/update_governance/runtime_risk_classifier.py": {
            "role": "Classifies the runtime risk level of an update",
            "content_spec": "Risk levels: safe (no runtime impact), low (additive only), medium (modifies existing behavior), high (changes core pipeline), critical (touches governance/safety/lifecycle spine). Methods: classify_risk(update_package) — returns RiskClassification with level, factors, mitigation_required. get_risk_factors(). Risk factors: touches_lock_zone, modifies_contracts, changes_routing, affects_governance."
        },
        "src/claire/platform/update_governance/target_alignment.py": {
            "role": "Checks if an update moves toward or away from the target state",
            "content_spec": "Integrates with evolution/target_state and evolution/forward_motion_policy. Methods: check_alignment(update) — returns (aligned, alignment_score, reasoning). get_target_contribution(update) — what capabilities does this move toward? detect_target_drift(update) — does this move away from any target?"
        },
        "src/claire/platform/update_governance/evolution_gate.py": {
            "role": "THE MASTER GATE — combines all checks into a single go/no-go decision",
            "content_spec": "Aggregates: authority_check, inspection_result, source_trust, signature_valid, dependency_impact, capability_diff, stage_impact, runtime_risk, target_alignment, regression_guard. Methods: evaluate(update) — returns GateDecision(approved, blocked_reasons, warnings, conditions). Gate requires ALL checks to pass. Any single failure blocks the update. Decision logged to data/update_governance/approvals/."
        },
        "src/claire/platform/update_governance/migration_planner.py": {
            "role": "Plans the migration path for approved updates",
            "content_spec": "Creates ordered migration steps: backup targets, file operations, configuration changes, test runs, validation checks. Methods: create_plan(approved_update) — returns MigrationPlan with steps, estimated_duration, rollback_points. validate_plan(). get_critical_path(). Plans stored in data/update_governance/staged/."
        },
        "src/claire/platform/update_governance/protected_path_guard.py": {
            "role": "Hard protection for paths that must NEVER be modified without explicit authority",
            "content_spec": "Protected paths: src/claire/lifecycle/ (governance spine), src/claire/governance/ (gates), src/claire/safety/ (safety layer), src/claire/evolution/ (evolution layer), src/claire/platform/update_governance/ (this layer — self-protection), data/evolution/verified_states/ (immutable proofs). Methods: is_protected(path), check_modification_allowed(path, authority), get_protection_reason(path). HARD BLOCK — no override without owner authority."
        },
        "src/claire/platform/update_governance/staged_installer.py": {
            "role": "Staged installation — installs to staging area first, validates, then promotes",
            "content_spec": "Three-stage install: 1) Copy to data/update_governance/staged/, 2) Run validation_gauntlet on staged files, 3) Promote to live system only if gauntlet passes. Methods: stage_update(update), validate_staged(), promote_staged(), abort_staged(). Never writes directly to live system. Staging area is ephemeral — cleaned after promotion or abort."
        },
        "src/claire/platform/update_governance/validation_gauntlet.py": {
            "role": "Post-install validation — runs every test and check after staging",
            "content_spec": "Gauntlet checks: 1) All existing tests pass, 2) All stage contracts valid, 3) All governance gates operational, 4) No capability regression (via regression_guard), 5) Runtime smoke test, 6) Import verification (all new modules importable). Methods: run_gauntlet(staged_update) — returns GauntletResult(passed, failed_checks, warnings). ALL checks must pass for promotion."
        },
        "src/claire/platform/update_governance/rollback_orchestrator.py": {
            "role": "Automatic rollback if anything goes wrong during or after update",
            "content_spec": "Creates rollback points before every update. Methods: create_rollback_point() — snapshots current state to data/update_governance/rollback_points/. rollback_to(point_id) — restores system to previous state. verify_rollback_integrity(point_id). auto_rollback_on_failure() — triggered automatically if validation_gauntlet fails after promotion. Rollback is atomic — either fully restores or fails safely."
        },
        "src/claire/platform/update_governance/audit_writer.py": {
            "role": "Immutable audit trail for every update operation",
            "content_spec": "Logs every action: inspection, gate_decision, staging, validation, promotion, rollback, approval, rejection. Fields: timestamp, action, actor (owner/system/external), target_paths, decision, reasoning, evidence_hash. Methods: log_action(), get_audit_trail(time_range), get_trail_for_update(update_id), verify_trail_integrity(). Append-only — no modification or deletion. Writes to data/update_governance/reports/."
        },
        "src/claire/platform/update_governance/approval_policy.py": {
            "role": "Defines approval requirements based on update risk level",
            "content_spec": "Policy rules: safe → auto-approve, low → auto-approve with logging, medium → require review before promotion, high → require explicit owner approval, critical → require owner approval + backup verification + rollback point confirmed. Methods: get_required_approval(risk_level), check_approval_granted(update_id), request_approval(update, risk_classification). Approvals stored in data/update_governance/approvals/."
        },
        "src/claire/platform/update_governance/update_orchestrator.py": {
            "role": "Master orchestrator — drives the entire update governance pipeline",
            "content_spec": "Orchestrates the full pipeline: 1) Receive update, 2) package_inspector.inspect(), 3) source_trust.evaluate(), 4) signature_verifier.verify(), 5) authority_map.check(), 6) dependency_impact_analyzer.analyze(), 7) capability_diff.diff(), 8) lifecycle_stage_impact.assess(), 9) runtime_risk_classifier.classify(), 10) target_alignment.check(), 11) evolution_gate.evaluate() — GO/NO-GO, 12) approval_policy.get_required(), 13) migration_planner.create_plan(), 14) rollback_orchestrator.create_rollback_point(), 15) staged_installer.stage(), 16) validation_gauntlet.run(), 17) staged_installer.promote() or rollback_orchestrator.rollback(), 18) audit_writer.log(). Entry point: process_update(package_path)."
        },
    }
},

# ──────────────────────────────────────────────────────────────────────────
#  PHASE 3: API ROUTE + FRONTEND PANELS
# ──────────────────────────────────────────────────────────────────────────
{
    "phase": 3,
    "name": "API Route & Frontend Panels",
    "version": "v10.3.1-phase3",
    "description": "API route for update governance + 3 frontend panels for evolution visibility",
    "depends_on": [1, 2],
    "new_folders": [
        "src/frontend/system",
    ],
    "new_files": {
        "src/claire/api/routes_update_governance.py": {
            "role": "API routes for the update governance system",
            "content_spec": "Endpoints: GET /api/v3/governance/update/status — current update pipeline status. POST /api/v3/governance/update/inspect — trigger package inspection. POST /api/v3/governance/update/approve — owner approval for pending updates. GET /api/v3/governance/update/audit — audit trail. GET /api/v3/governance/update/rollback-points — available rollback points. POST /api/v3/governance/update/rollback — trigger rollback. GET /api/v3/evolution/status — full evolution status. GET /api/v3/evolution/identity — project identity. GET /api/v3/evolution/timeline — version timeline. GET /api/v3/evolution/capabilities — capability matrix. GET /api/v3/evolution/target — target state + gap analysis. GET /api/v3/evolution/regressions — regression reports. All routes integrate with update_orchestrator and evolution_orchestrator."
        },
        "src/frontend/system/UpdateGovernancePanel.js": {
            "role": "Frontend panel — update governance pipeline visualization",
            "content_spec": "Displays: incoming updates queue, inspection results, gate decisions (go/no-go with all check statuses), staging status, validation gauntlet results, approval requests, active rollback points, audit trail viewer. Interactive: approve/reject pending updates, trigger rollback, inspect package details. Color-coded pipeline stages: green (passed), red (blocked), yellow (pending), gray (not started)."
        },
        "src/frontend/system/EvolutionMemoryPanel.js": {
            "role": "Frontend panel — evolution memory and project identity",
            "content_spec": "Displays: project identity block, version timeline (visual timeline from v1 to current), target state with completion percentage, capability matrix (grid of all capabilities by status), evolution velocity chart, forward motion trend, lessons learned feed. Interactive: drill into any version, filter capabilities by status, compare capability snapshots over time."
        },
        "src/frontend/system/RegressionGuardPanel.js": {
            "role": "Frontend panel — regression detection and prevention",
            "content_spec": "Displays: verified state history, latest regression scan results, regression report viewer, protected paths list, capability diff viewer (before/after any change). Interactive: trigger regression scan, view regression details, compare verified states. Red/green indicators for each verified capability. Alert system for detected regressions."
        },
    }
},

# ──────────────────────────────────────────────────────────────────────────
#  PHASE 4: DATA DIRECTORIES
#  Governed data storage for evolution state and update governance artifacts
# ──────────────────────────────────────────────────────────────────────────
{
    "phase": 4,
    "name": "Data Directories",
    "version": "v10.3.1-phase4",
    "description": "Governed data storage directories for evolution and update governance",
    "depends_on": [],
    "new_folders": [
        "data/evolution",
        "data/evolution/origin",
        "data/evolution/identity",
        "data/evolution/timeline",
        "data/evolution/target_state",
        "data/evolution/verified_states",
        "data/evolution/capability_snapshots",
        "data/evolution/regression_reports",
        "data/evolution/forward_decisions",
        "data/evolution/completion_memory",
        "data/update_governance",
        "data/update_governance/incoming",
        "data/update_governance/inspected",
        "data/update_governance/staged",
        "data/update_governance/backups",
        "data/update_governance/reports",
        "data/update_governance/approvals",
        "data/update_governance/rollback_points",
        "data/update_governance/signatures",
        "data/update_governance/quarantined",
    ],
    "new_files": {}
},

]

# ============================================================================
#  INSTALLER ENGINE
# ============================================================================

def get_summary():
    total_folders = sum(len(p["new_folders"]) for p in PHASES)
    total_files = sum(len(p["new_files"]) for p in PHASES)
    return total_folders, total_files

def preflight_check(target, phase_filter=None):
    """Check target exists and detect conflicts."""
    report = {
        "target": target,
        "target_exists": os.path.isdir(target),
        "timestamp": datetime.now().isoformat(),
        "installer_version": INSTALLER_VERSION,
        "installer_id": INSTALLER_ID,
        "phases": [],
        "conflicts": [],
        "ready": True
    }

    for phase in PHASES:
        if phase_filter is not None and phase["phase"] != phase_filter:
            continue

        phase_report = {
            "phase": phase["phase"],
            "name": phase["name"],
            "new_folders": len(phase["new_folders"]),
            "new_files": len(phase["new_files"]),
            "conflicts": []
        }

        # Check for existing files (skip-if-exists safety)
        for fpath in phase["new_files"]:
            full = os.path.join(target, fpath.replace("/", os.sep))
            if os.path.exists(full):
                phase_report["conflicts"].append(fpath)
                report["conflicts"].append(fpath)

        report["phases"].append(phase_report)

    if not report["target_exists"]:
        report["ready"] = False

    return report

def create_file_content(filepath, spec):
    """Generate governed file content with spec headers."""
    filename = os.path.basename(filepath)
    ext = filename.rsplit(".", 1)[-1] if "." in filename else ""

    if ext == "py":
        lines = [
            f'"""',
            f'{spec.get("role", filename)}',
            f'',
            f'Claire v{INSTALLER_VERSION} — Evolution & Update Governance',
            f'Generated by installer {INSTALLER_ID} on {INSTALLER_DATE}',
            f'',
            f'Content Specification:',
            f'  {spec.get("content_spec", "See module docstring")}',
            f'"""',
            f'',
        ]
        if filename == "__init__.py":
            lines.append(f'# {spec.get("content_spec", "Package init")}')
        else:
            module_name = filename.replace(".py", "")
            class_name = "".join(w.capitalize() for w in module_name.split("_"))
            lines.extend([
                f'class {class_name}:',
                f'    """',
                f'    {spec.get("role", "")}',
                f'    """',
                f'',
                f'    def __init__(self):',
                f'        self._initialized = False',
                f'',
                f'    def initialize(self):',
                f'        """Initialize the {module_name} subsystem."""',
                f'        self._initialized = True',
                f'        return self',
                f'',
            ])
        return "\n".join(lines) + "\n"

    elif ext == "js":
        lines = [
            f'/**',
            f' * {spec.get("role", filename)}',
            f' *',
            f' * Claire v{INSTALLER_VERSION} — Evolution & Update Governance',
            f' * Generated by installer {INSTALLER_ID} on {INSTALLER_DATE}',
            f' *',
            f' * Content Specification:',
            f' *   {spec.get("content_spec", "See module header")}',
            f' */',
            f'',
            f'// {spec.get("role", "")}',
            f'export default class {filename.replace(".js", "").replace("_", "")} {{',
            f'  constructor() {{',
            f'    this.initialized = false;',
            f'  }}',
            f'',
            f'  init() {{',
            f'    this.initialized = true;',
            f'    return this;',
            f'  }}',
            f'}}',
        ]
        return "\n".join(lines) + "\n"

    elif ext == "json":
        return json.dumps({
            "_meta": {
                "generated_by": f"claire_installer_{INSTALLER_ID}",
                "version": INSTALLER_VERSION,
                "date": INSTALLER_DATE,
                "role": spec.get("role", ""),
                "content_spec": spec.get("content_spec", "")
            }
        }, indent=2) + "\n"

    return f"# {spec.get('role', filename)}\n# Content spec: {spec.get('content_spec', '')}\n"

def install_phase(target, phase, dry_run=False):
    """Install a single phase."""
    results = {"phase": phase["phase"], "name": phase["name"], "folders_created": [], "files_created": [], "skipped": [], "errors": []}

    # Create folders
    for folder in phase["new_folders"]:
        full = os.path.join(target, folder.replace("/", os.sep))
        if os.path.exists(full):
            results["skipped"].append(f"FOLDER EXISTS: {folder}")
        elif dry_run:
            results["folders_created"].append(f"WOULD CREATE: {folder}")
        else:
            try:
                os.makedirs(full, exist_ok=True)
                results["folders_created"].append(folder)
            except Exception as e:
                results["errors"].append(f"FOLDER ERROR: {folder} — {e}")

        # Create .gitkeep for empty data directories
        if not dry_run and os.path.exists(full) and folder.startswith("data/"):
            gitkeep = os.path.join(full, ".gitkeep")
            if not os.path.exists(gitkeep) and not any(f.startswith(folder + "/") for f in phase["new_files"]):
                Path(gitkeep).touch()

    # Create files
    for fpath, spec in phase["new_files"].items():
        full = os.path.join(target, fpath.replace("/", os.sep))
        if os.path.exists(full):
            results["skipped"].append(f"FILE EXISTS: {fpath}")
        elif dry_run:
            results["files_created"].append(f"WOULD CREATE: {fpath}")
        else:
            try:
                os.makedirs(os.path.dirname(full), exist_ok=True)
                content = create_file_content(fpath, spec)
                with open(full, "w", encoding="utf-8") as f:
                    f.write(content)
                results["files_created"].append(fpath)
            except Exception as e:
                results["errors"].append(f"FILE ERROR: {fpath} — {e}")

    return results

def write_audit_log(target, results, preflight):
    """Write install audit log."""
    log_dir = os.path.join(target, ".claire_install_logs")
    os.makedirs(log_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(log_dir, f"install_{timestamp}_evo_gov_{INSTALLER_ID}.json")

    log_data = {
        "installer_version": INSTALLER_VERSION,
        "installer_id": INSTALLER_ID,
        "timestamp": datetime.now().isoformat(),
        "preflight": preflight,
        "results": results
    }

    with open(log_path, "w", encoding="utf-8") as f:
        json.dump(log_data, f, indent=2)

    return log_path

def main():
    parser = argparse.ArgumentParser(description="Claire v10.3.1 Evolution & Update Governance Installer")
    parser.add_argument("--install", action="store_true", help="Execute installation (default is dry run)")
    parser.add_argument("--phase", type=int, help="Install specific phase only (1-4)")
    parser.add_argument("--target", default=DEFAULT_TARGET, help=f"Target directory (default: {DEFAULT_TARGET})")
    args = parser.parse_args()

    total_folders, total_files = get_summary()

    print("=" * 72)
    print("  CLAIRE v10.3.1 — Evolution & Update Governance Installer")
    print(f"  {total_folders} new folders | {total_files} new files | 4 phases")
    print(f"  Installer ID: {INSTALLER_ID}")
    print("=" * 72)
    print()

    # Preflight
    print("[PREFLIGHT] Checking target directory...")
    preflight = preflight_check(args.target, args.phase)

    if not preflight["target_exists"]:
        print(f"  ERROR: Target directory not found: {args.target}")
        print(f"  Use --target to specify the Claire root directory")
        sys.exit(1)

    print(f"  Target: {args.target}")
    print(f"  Status: {'READY' if preflight['ready'] else 'NOT READY'}")

    if preflight["conflicts"]:
        print(f"  Conflicts: {len(preflight['conflicts'])} files already exist (will be skipped)")
        for c in preflight["conflicts"]:
            print(f"    SKIP: {c}")
    print()

    # Phase summary
    for p in preflight["phases"]:
        deps = [ph for ph in PHASES if ph["phase"] == p["phase"]][0].get("depends_on", [])
        dep_str = f" (depends on phase{'s' if len(deps)>1 else ''} {', '.join(str(d) for d in deps)})" if deps else ""
        conflict_str = f" [{len(p['conflicts'])} conflicts]" if p["conflicts"] else ""
        print(f"  Phase {p['phase']}: {p['name']} — {p['new_folders']} folders, {p['new_files']} files{dep_str}{conflict_str}")
    print()

    if not args.install:
        print("[DRY RUN] No changes made. Use --install to execute.")
        print()

        # Show what would be created
        for phase in PHASES:
            if args.phase is not None and phase["phase"] != args.phase:
                continue
            print(f"  Phase {phase['phase']}: {phase['name']}")
            for folder in phase["new_folders"]:
                print(f"    [DIR]  {folder}/")
            for fpath in phase["new_files"]:
                print(f"    [FILE] {fpath}")
            print()
        return

    # Install
    print("[INSTALLING]")
    all_results = []
    for phase in PHASES:
        if args.phase is not None and phase["phase"] != args.phase:
            continue

        print(f"\n  Phase {phase['phase']}: {phase['name']}...")
        results = install_phase(args.target, phase, dry_run=False)
        all_results.append(results)

        for f in results["folders_created"]:
            print(f"    [DIR]  Created: {f}")
        for f in results["files_created"]:
            print(f"    [FILE] Created: {f}")
        for s in results["skipped"]:
            print(f"    [SKIP] {s}")
        for e in results["errors"]:
            print(f"    [ERR]  {e}")

        created = len(results["folders_created"]) + len(results["files_created"])
        skipped = len(results["skipped"])
        errors = len(results["errors"])
        print(f"    Result: {created} created, {skipped} skipped, {errors} errors")

    # Audit log
    log_path = write_audit_log(args.target, all_results, preflight)
    print(f"\n[AUDIT] Log written: {log_path}")

    # Summary
    total_created = sum(len(r["folders_created"]) + len(r["files_created"]) for r in all_results)
    total_skipped = sum(len(r["skipped"]) for r in all_results)
    total_errors = sum(len(r["errors"]) for r in all_results)

    print()
    print("=" * 72)
    print(f"  COMPLETE: {total_created} created | {total_skipped} skipped | {total_errors} errors")
    print("=" * 72)

if __name__ == "__main__":
    main()
