#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil
from datetime import datetime, timezone
from pathlib import Path

INSTALLER_NAME = "Claire Modern Dashboard Web UI Installer"
INSTALLER_VERSION = "11.34-11.40"
DEFAULT_TARGET = Path.home() / "OneDrive" / "Desktop" / "Claire"
FILES = {
  "src/frontend/command_center/modern/index.html": "<!doctype html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"utf-8\"/>\n  <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"/>\n  <title>Claire Syntalion Command Center</title>\n  <link rel=\"stylesheet\" href=\"./modern_dashboard.css\"/>\n</head>\n<body>\n  <aside class=\"sidebar\">\n    <div class=\"brand\"><div class=\"logo\">C</div><div><b>Claire Syntalion</b><span>Operational Intelligence Command Center</span></div></div>\n    <nav id=\"nav\"></nav>\n    <section class=\"guide-card\"><b>Operator Rule</b><p>Missing dashboard data means Claire needs proof files, telemetry, labels, or replay evidence \u2014 not more feature sprawl.</p></section>\n  </aside>\n  <main>\n    <header>\n      <div><p class=\"eyebrow\">Governance-first deployment scaling</p><h1 id=\"title\">Executive Overview</h1></div>\n      <div class=\"actions\"><button id=\"refresh\">Refresh State</button><button id=\"help\">Use Guide</button></div>\n    </header>\n    <section id=\"strip\" class=\"strip\"></section>\n    <section id=\"content\" class=\"grid\"></section>\n  </main>\n  <dialog id=\"guide\">\n    <h2>Claire Dashboard Use Guide</h2>\n    <p>This command center is for operating Claire through the maturity phase: evidence accumulation, replay proof, governance controls, live activation gates, and package readiness.</p>\n    <ol>\n      <li>Launch Claire using the desktop launcher.</li>\n      <li>Use Executive Overview for decision, confidence, and weak spots.</li>\n      <li>Use Lifecycle Runtime to verify route, terminal state, and stage output.</li>\n      <li>Use Data Readiness to improve lineage, labels, rights, source coverage, and workflow telemetry.</li>\n      <li>Use Evidence Ops and Benchmarks before expanding live activation.</li>\n      <li>Use Governance Controls to block unsafe or unsupported escalation.</li>\n    </ol>\n    <button onclick=\"document.getElementById('guide').close()\">Close</button>\n  </dialog>\n  <script src=\"./modern_dashboard.js\"></script>\n</body>\n</html>\n",
  "src/frontend/command_center/modern/modern_dashboard.css": ":root{--bg:#060914;--panel:rgba(17,24,39,.86);--panel2:rgba(31,41,55,.78);--line:rgba(255,255,255,.1);--text:#eef4ff;--muted:#95a3b8;--a:#7dd3fc;--b:#a78bfa;--g:#34d399;--w:#fbbf24;--r:#fb7185}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 20% 10%,rgba(125,211,252,.18),transparent 35%),radial-gradient(circle at 80% 0,rgba(167,139,250,.18),transparent 35%),linear-gradient(135deg,#05070d,#0b1020 52%,#101827);color:var(--text);font-family:Inter,Segoe UI,Arial,sans-serif;display:grid;grid-template-columns:310px 1fr}.sidebar{border-right:1px solid var(--line);background:rgba(3,7,18,.72);backdrop-filter:blur(18px);padding:24px;height:100vh;position:sticky;top:0;overflow:auto}.brand{display:flex;gap:14px;align-items:center;margin-bottom:26px}.logo{width:52px;height:52px;border-radius:18px;display:grid;place-items:center;color:#020617;font-weight:900;font-size:26px;background:linear-gradient(135deg,var(--a),var(--b));box-shadow:0 20px 60px rgba(125,211,252,.18)}.brand span{display:block;color:var(--muted);font-size:12px;margin-top:4px}.guide-card{margin-top:22px;border:1px solid var(--line);background:rgba(255,255,255,.05);border-radius:20px;padding:16px}.guide-card p{color:var(--muted);font-size:13px;line-height:1.5}nav{display:grid;gap:8px}nav button{border:1px solid transparent;background:transparent;color:var(--muted);padding:12px;border-radius:14px;text-align:left;cursor:pointer;font-weight:700}nav button:hover,nav button.active{color:var(--text);background:linear-gradient(135deg,rgba(125,211,252,.16),rgba(167,139,250,.14));border-color:rgba(125,211,252,.22)}main{padding:30px;overflow:auto}header{display:flex;justify-content:space-between;gap:18px;align-items:flex-start;margin-bottom:20px}.eyebrow{color:var(--a);font-weight:900;letter-spacing:.12em;text-transform:uppercase;font-size:12px;margin:0 0 8px}h1{font-size:36px;letter-spacing:-.045em;margin:0}.actions{display:flex;gap:10px}button{border:1px solid var(--line);background:rgba(255,255,255,.07);color:var(--text);padding:11px 14px;border-radius:14px;cursor:pointer;font-weight:800}.strip{display:grid;grid-template-columns:repeat(5,minmax(140px,1fr));gap:12px;margin-bottom:18px}.pill,.card{border:1px solid var(--line);background:var(--panel);border-radius:24px;box-shadow:0 24px 80px rgba(0,0,0,.35)}.pill{padding:14px}.pill small{display:block;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;font-weight:800}.pill strong{display:block;margin-top:8px;font-size:18px}.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:16px}.card{grid-column:span 4;padding:18px;min-height:160px}.card.wide{grid-column:span 8}.card.full{grid-column:1/-1}.card h3{margin:0 0 10px}.card p{color:var(--muted);line-height:1.55}.metric{display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid var(--line)}.metric:last-child{border-bottom:0}.metric span{color:var(--muted)}.good{color:var(--g)}.warn{color:var(--w)}.bad{color:var(--r)}.bar{height:10px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;margin:8px 0 12px}.bar div{height:100%;background:linear-gradient(90deg,var(--a),var(--b))}.item{border:1px solid var(--line);background:rgba(255,255,255,.04);border-radius:16px;padding:12px;margin:9px 0}.item b{display:block}.item span{display:block;color:var(--muted);font-size:13px;line-height:1.45;margin-top:4px}.code{white-space:pre-wrap;word-break:break-word;font-family:Consolas,monospace;color:#c7d2fe;background:rgba(0,0,0,.25);border:1px solid var(--line);border-radius:16px;padding:14px;max-height:440px;overflow:auto}dialog{max-width:760px;border:1px solid var(--line);border-radius:24px;background:#0b1220;color:var(--text);padding:24px}dialog p,dialog li{color:var(--muted);line-height:1.6}@media(max-width:1000px){body{display:block}.sidebar{position:relative;height:auto}.strip{grid-template-columns:repeat(2,1fr)}.card,.card.wide{grid-column:1/-1}}",
  "src/frontend/command_center/modern/modern_dashboard.js": "const tabs=[['overview','Executive Overview'],['lifecycle','Lifecycle Runtime'],['data','Data Readiness'],['evidence','Evidence Ops'],['live','Live Activation'],['bench','Benchmarks + Replay'],['portfolio','Portfolio + Acquirer'],['design','Breakthrough + Design'],['packages','Packages + Export'],['governance','Governance Controls'],['telemetry','Telemetry + Learning'],['system','System Proof']];let active='overview';let state={status:'waiting',run_id:'waiting-for-output',mode:'desktop',decision_classification:'UNKNOWN',breakthrough_classification:'UNKNOWN',domain:'unknown',scores:{}};const $=id=>document.getElementById(id);function pct(v){v=Number(v||0);return Math.round(v*100)+'%'}function cls(v){v=Number(v||0);return v>=.7?'good':v>=.4?'warn':'bad'}function val(v,f='\u2014'){return v===undefined||v===null||v===''?f:v}function metric(k,v){return `<div class=\"metric\"><span>${k}</span><b>${v}</b></div>`}function prog(k,v){v=Number(v||0);return metric(k,`<span class=\"${cls(v)}\">${pct(v)}</span>`)+`<div class=\"bar\"><div style=\"width:${Math.max(0,Math.min(100,v*100))}%\"></div></div>`}function card(t,b,c=''){return `<article class=\"card ${c}\"><h3>${t}</h3>${b}</article>`}function list(items){if(!items||!items.length)return '<p>No records available yet.</p>';return items.map(x=>typeof x==='string'?`<div class=\"item\"><b>${x}</b></div>`:`<div class=\"item\"><b>${val(x.action||x.name||x.gap||x.falsifier||x.title,'Untitled')}</b><span>${val(x.purpose||x.reason||x.objective||x.why_it_matters||x.test||x.priority,'')}</span></div>`).join('')}async function fetchAny(paths){for(const p of paths){try{const r=await fetch(p+'?t='+Date.now());if(r.ok)return await r.json()}catch(e){}}return null}async function load(){state=await fetchAny(['/api/dashboard/state','/output/core_run_output.json','/data/dashboard/state_snapshots/desktop_launcher_state.json','./core_run_output.json'])||state;render()}function nav(){ $('nav').innerHTML=tabs.map(([id,n])=>`<button class=\"${id===active?'active':''}\" data-id=\"${id}\">${n}</button>`).join('');document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{active=b.dataset.id;render()})}function strip(){let s=state.scores||{};$('strip').innerHTML=[['Run',state.run_id],['Decision',state.decision_classification],['Breakthrough',state.breakthrough_classification],['Data Ready',pct(s.data_readiness_score)],['Pilot Ready',pct(s.pilot_readiness_score)]].map(x=>`<div class=\"pill\"><small>${x[0]}</small><strong>${val(x[1])}</strong></div>`).join('')}function overview(){let s=state.scores||{};return card('Runtime Status',metric('Status',val(state.status))+metric('Mode',val(state.mode))+metric('Domain',val(state.domain))+metric('Run ID',val(state.run_id)))+card('Maturity Scores',prog('Portfolio',s.portfolio_score)+prog('Breakthrough',s.breakthrough_score)+prog('Data Readiness',s.data_readiness_score)+prog('Pilot Readiness',s.pilot_readiness_score))+card('Weak Spots',prog('Validation Burden',s.validation_burden_score)+prog('Routing Confidence',s.routing_confidence_score)+prog('Integration Readiness',s.integration_readiness_score)+'<p>Low values mean Claire is correctly asking for proof.</p>')+card('Recommended Actions',list(state.recommended_next_actions||state.opportunity_discovery?.recommended_next_actions),'wide')+card('Keywords / Signals',list((state.keywords||[]).slice(0,20)),'wide')}function lifecycle(){return card('Lifecycle Runtime',metric('Terminal / Status',val(state.terminal_state||state.status))+metric('Route',val(state.route||state.thesis_formation?.route_recommendation))+metric('Decision',val(state.decision_classification))+'<p>Verify autonomous execution reached a meaningful terminal state.</p>')+card('Thesis Formation',`<p>${val(state.thesis_formation?.thesis_statement,'No thesis statement available yet.')}</p>`+metric('Thesis Score',pct(state.scores?.thesis_score))+metric('Trend Score',pct(state.scores?.trend_discovery_score)),'wide')+card('Raw Runtime Output',`<div class=\"code\">${JSON.stringify(state,null,2)}</div>`,'full')}function data(){let s=state.scores||{},ki=state.knowledge_ingestion||{};return card('Readiness Scorecard',prog('Data Readiness',s.data_readiness_score)+prog('Source Quality',s.source_quality_score)+prog('Coverage',s.coverage_score)+prog('Knowledge Quality',s.knowledge_quality_score))+card('Lineage + Provenance',metric('Input Hash',val(ki.lineage?.input_hash))+metric('Sources',val((ki.lineage?.source_names||[]).join(', ')))+`<p>${val(ki.lineage?.lineage_note,'Lineage note not available.')}</p>`,'wide')+card('Data Gaps',list(state.opportunity_discovery?.evidence_gaps),'wide')+card('Instructions','<p>Add source records, provenance, source rights, labels, benchmark outcomes, replay examples, and operator review telemetry.</p>')}function evidence(){return card('Evidence Status',prog('Evidence Signal',state.scores?.evidence_signal_score)+prog('Signal Quality',state.scores?.signal_quality_score)+prog('Source Quality',state.scores?.source_quality_score))+card('Validation Roadmap',list(state.opportunity_discovery?.validation_roadmap||state.breakthrough_synthesis?.validation_path),'wide')+card('Falsifiers',list(state.breakthrough_synthesis?.falsifiers),'wide')+card('Operator Rule','<p>Every important claim should attach to evidence packets, labels, replay results, source lineage, and reviewer notes.</p>')}function live(){return card('Live Activation Gate',metric('Mode','Controlled / allowlist only')+metric('Autonomous Action','Disabled unless governed')+metric('Required','Source allowlist + lineage + risk gate'))+card('Live Workflow',list(['Approve source','Start source pilot','Record source decision','Quarantine weak evidence','Promote only after replay']),'wide')+card('Risk Console','<p>Keep live activation controlled until readiness, telemetry density, and validation burden improve.</p>')}function bench(){return card('Benchmark Health',prog('Export Package',state.scores?.export_package_score)+prog('Export Writer',state.scores?.export_writer_score)+prog('Validation Burden',state.scores?.validation_burden_score))+card('Benchmark Instructions','<p>Build historical examples, expected outcomes, replay runs, label adjudications, false-positive records, and drift reports.</p>','wide')+card('Historical Tests Needed',list(['Historical opportunity benchmark','Expert baseline comparison','False-positive suppression report','Replay drift report','Outcome label coverage report','Confidence calibration table']),'wide')}function portfolio(){return card('Portfolio Intelligence',prog('Portfolio',state.scores?.portfolio_score)+prog('Portfolio Optimization',state.scores?.portfolio_optimization_score)+prog('Acquisition',state.scores?.acquisition_score))+card('Opportunity Thesis',`<p>${val(state.opportunity_discovery?.opportunity_thesis,'No opportunity thesis available yet.')}</p>`,'wide')+card('Acquirer Matches',list((state.acquirer_matches||[]).map(a=>({name:`${a.name} \u2014 ${pct(a.match_score)}`,reason:(a.rationale||[]).join('; ')}))),'wide')}function design(){return card('Breakthrough Classification',metric('Classification',val(state.breakthrough_synthesis?.breakthrough_classification?.classification||state.breakthrough_classification))+prog('Breakthrough',state.scores?.breakthrough_score)+prog('Synthesis',state.scores?.breakthrough_synthesis_score)+prog('Non-obviousness',state.scores?.non_obviousness_score))+card('Breakthrough Thesis',`<p>${val(state.breakthrough_synthesis?.breakthrough_thesis,'No breakthrough thesis available yet.')}</p>`,'wide')+card('Design Routing',metric('Recommended',val(state.breakthrough_synthesis?.portfolio_implications?.design_routing_recommendation,'validate_before_design'))+'<p>Design expansion should follow validation, not precede it.</p>')}function packages(){return card('Package Readiness',prog('Packaging',state.scores?.packaging_readiness_score)+prog('Productization',state.scores?.productization_score)+prog('Strategic Positioning',state.scores?.strategic_positioning_score)+prog('Acquirer Positioning',state.scores?.acquirer_positioning_score))+card('Commercialization',`<p>${val(state.breakthrough_synthesis?.commercialization_implications?.commercial_risk_note,'No commercialization note available.')}</p>`,'wide')+card('Binder Artifacts',list(state.breakthrough_synthesis?.portfolio_implications?.recommended_artifacts),'wide')}function governance(){return card('Governance Contract',metric('Live Actions','Gated')+metric('Runtime Mutation','No')+metric('Evidence Required','Yes')+metric('False Positive Controls','Required'))+card('Governance Instructions','<p>Approve sources, monitor gates, review evidence packets, enforce no-go criteria, and block unsupported escalation.</p>','wide')+card('No-Go Criteria',list(['No source rights','No lineage','No benchmark replay','No operator review','Low data readiness','High drift or false positive rate']),'wide')}function telemetry(){return card('Telemetry Density',prog('Signal Quality',state.scores?.signal_quality_score)+prog('Semantic Density',state.scores?.semantic_density_score)+prog('Control Signal',state.scores?.control_signal_score))+card('Learning Loop Instructions','<p>Capture workflow sessions, operator reviews, adopted outputs, rejected outputs, benchmark labels, replay outcomes, and source reliability over time.</p>','wide')+card('Telemetry Events Needed',list(['Run started','Output reviewed','Recommendation accepted/rejected','Evidence packet attached','Benchmark replay completed','Live source promoted/quarantined','False positive recorded','Package exported']),'wide')}function system(){return card('System State',metric('Launcher',val(state.launcher?.preferred_target||'desktop launcher'))+metric('Active Version',val(state.active_version||state.version||'unknown'))+metric('Status',val(state.status)))+card('Repository Proof','<p>This UI expects lifecycle outputs, data readiness, evidence ops, live activation, benchmark datasets, dashboard snapshots, and install reports.</p>','wide')+card('Raw State',`<div class=\"code\">${JSON.stringify(state,null,2)}</div>`,'full')}function render(){nav();strip();let map={overview,lifecycle,data,evidence,live,bench,portfolio,design,packages,governance,telemetry,system};$('title').textContent=tabs.find(x=>x[0]===active)[1];$('content').innerHTML=map[active]()}$('refresh').onclick=load;$('help').onclick=()=>$('guide').showModal();load();",
  "docs/dashboard/modern_dashboard_use_guide.md": "# Claire Modern Dashboard Use Guide\n\nThis installs a modern command-center web UI for Claire.\n\n## Install\n\nFrom the Claire root:\n\n```bat\npython claire_modern_dashboard_web_ui_installer.py --install\n```\n\n## Installed files\n\n```text\nsrc/frontend/command_center/modern/index.html\nsrc/frontend/command_center/modern/modern_dashboard.css\nsrc/frontend/command_center/modern/modern_dashboard.js\ndocs/dashboard/modern_dashboard_use_guide.md\ndata/dashboard/render_contracts/modern_dashboard_contract.json\n```\n\n## Open\n\nUse your normal desktop launcher first:\n\n```bat\nSTART_CLAIRE_DESKTOP.bat\n```\n\nThen open:\n\n```text\nsrc/frontend/command_center/modern/index.html\n```\n\n## Functionality included\n\n- Executive Overview\n- Lifecycle Runtime\n- Data Readiness\n- Evidence Ops\n- Controlled Live Activation\n- Benchmarks + Replay\n- Portfolio + Acquirer\n- Breakthrough + Design\n- Packages + Export\n- Governance Controls\n- Telemetry + Learning\n- System Proof\n\n## Safety\n\nThis installer does not modify runtime, routing, scoring, live permissions, or core_run_output.json.\n",
  "data/dashboard/render_contracts/modern_dashboard_contract.json": "{\n  \"dashboard\": \"Claire Modern Command Center\",\n  \"version\": \"11.34-11.40\",\n  \"reads\": [\n    \"/api/dashboard/state\",\n    \"/output/core_run_output.json\",\n    \"/data/dashboard/state_snapshots/desktop_launcher_state.json\",\n    \"./core_run_output.json\"\n  ],\n  \"does_not_modify_runtime\": true,\n  \"does_not_modify_routing\": true,\n  \"does_not_modify_scoring\": true,\n  \"operator_surfaces\": [\n    \"overview\",\n    \"lifecycle\",\n    \"data_readiness\",\n    \"evidence_ops\",\n    \"live_activation\",\n    \"benchmarks\",\n    \"portfolio\",\n    \"design\",\n    \"packages\",\n    \"governance\",\n    \"telemetry\",\n    \"system\"\n  ]\n}"
}

DIRS = [
    "src/frontend/command_center/modern",
    "docs/dashboard",
    "data/dashboard/render_contracts",
    "data/dashboard/state_snapshots",
    ".claire_install/reports"
]

def stamp():
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

def ensure_dir(path, install, actions):
    existed = path.exists()
    if install:
        path.mkdir(parents=True, exist_ok=True)
    actions.append({"action":"ensure_dir","path":str(path),"installed":install,"existed":existed})

def write_file(path, content, install, actions):
    existed = path.exists()
    backup = None
    if install:
        path.parent.mkdir(parents=True, exist_ok=True)
        if existed:
            backup_path = path.with_name(path.name + ".bak_" + stamp())
            shutil.copy2(path, backup_path)
            backup = str(backup_path)
        path.write_text(content, encoding="utf-8", newline="\n")
    actions.append({"action":"write_file","path":str(path),"installed":install,"existed":existed,"backup":backup})

def patch_launcher(root, install, actions):
    launcher = root / "START_CLAIRE_DESKTOP.bat"
    note = "\nREM Modern dashboard installed at: src\\frontend\\command_center\\modern\\index.html\n"
    if not launcher.exists():
        actions.append({"action":"launcher_note","installed":False,"reason":"START_CLAIRE_DESKTOP.bat missing"})
        return
    current = launcher.read_text(encoding="utf-8", errors="ignore")
    if "src\\frontend\\command_center\\modern\\index.html" in current:
        actions.append({"action":"launcher_note","installed":False,"reason":"already present"})
        return
    if install:
        backup = launcher.with_name(launcher.name + ".bak_" + stamp())
        shutil.copy2(launcher, backup)
        launcher.write_text(current.rstrip() + note, encoding="utf-8", newline="\n")
        actions.append({"action":"launcher_note","installed":True,"backup":str(backup)})
    else:
        actions.append({"action":"launcher_note","installed":False,"reason":"dry_run"})

def main():
    p = argparse.ArgumentParser(description=INSTALLER_NAME)
    p.add_argument("--target", default=str(DEFAULT_TARGET))
    p.add_argument("--install", action="store_true")
    args = p.parse_args()
    root = Path(args.target).expanduser().resolve()
    install = bool(args.install)
    print(f"{INSTALLER_NAME} {INSTALLER_VERSION}")
    print(f"Target: {root}")
    print("Mode:", "INSTALL" if install else "DRY RUN")
    if not root.exists():
        print(f"[ERROR] Target does not exist: {root}")
        return 2
    actions = []
    for d in DIRS:
        ensure_dir(root / d, install, actions)
    for rel, content in FILES.items():
        write_file(root / rel, content, install, actions)
    patch_launcher(root, install, actions)
    report = {
        "installer": INSTALLER_NAME,
        "installer_version": INSTALLER_VERSION,
        "installed": install,
        "installed_at_utc": datetime.now(timezone.utc).isoformat(),
        "target": str(root),
        "dashboard_entry": "src/frontend/command_center/modern/index.html",
        "actions": actions,
        "safety_contract": {
            "does_not_modify_backend_runtime": True,
            "does_not_modify_scoring": True,
            "does_not_modify_routing": True,
            "does_not_modify_core_run_output": True,
            "backs_up_replaced_files": True
        },
        "post_install": [
            "Launch Claire using START_CLAIRE_DESKTOP.bat.",
            "Open src/frontend/command_center/modern/index.html.",
            "Use the Use Guide button inside the dashboard.",
            "Continue evidence accumulation before live deployment expansion."
        ]
    }
    if install:
        report_path = root / ".claire_install" / "reports" / ("modern_dashboard_web_ui_" + stamp() + ".json")
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        print(f"[OK] Install report written: {report_path}")
    else:
        print("[DRY RUN] No files changed. Re-run with --install to apply.")
    print(json.dumps({"installed":install,"dashboard":"src/frontend/command_center/modern/index.html","files":list(FILES.keys())}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
