"""Bridge — MasterPass handoff layer."""
