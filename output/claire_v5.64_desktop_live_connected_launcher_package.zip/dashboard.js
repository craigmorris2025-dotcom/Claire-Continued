const state={runs:[],selected:null,files:[],active:null,timer:null,cursor:0,catalog:null};
const el=id=>document.getElementById(id); const fmt=(v,f='—')=>(v===undefined||v===null||v==='')?f:String(v);
function stat(id,msg,err=false){el(id).textContent=msg;el(id).style.color=err?'#f85149':'#8b949e'}
async function api(path,opt={}){const r=await fetch(path,opt);if(!r.ok)throw new Error(await r.text());const ct=r.headers.get('content-type')||'';return ct.includes('json')?r.json():r.text()}
function option(sel,id,name,extra=''){const o=document.createElement('option');o.value=id;o.textContent=extra?`${name} — ${extra}`:name;sel.appendChild(o)}
async function loadCatalog(){state.catalog=await api('/api/commands');const wf=el('workflowSelect'), em=el('executionModeSelect'), mu=el('marketUniverseSelect'), ind=el('industryDomainSelect'), buyer=el('buyerSegmentSelect'), obj=el('objectiveSelect'), cmd=el('commandSelect');state.catalog.workflow_modes.forEach(x=>option(wf,x.id,x.name));state.catalog.execution_modes.forEach(x=>option(em,x.id,x.name));state.catalog.market_universes.forEach(x=>option(mu,x.id,x.name,x.coverage_count_label));state.catalog.industry_domains.forEach(x=>option(ind,x.id,x.name,x.classification));state.catalog.buyer_segments.forEach(x=>option(buyer,x.id,x.name));state.catalog.opportunity_objectives.forEach(x=>option(obj,x.id,x.name));function fillCmd(){cmd.innerHTML='';state.catalog.commands.filter(c=>c.workflow===wf.value).forEach(c=>option(cmd,c.id,c.name))}wf.onchange=fillCmd;fillCmd()}
async function applyDesktopLiveMode(){try{const h=await api('/api/health');if(!h.desktop_live)return;const em=el('executionModeSelect'),mu=el('marketUniverseSelect'),ind=el('industryDomainSelect'),obj=el('objectiveSelect');if(em)em.value='hybrid';if(mu)mu.value='sp500_public';if(ind)ind.value='information_technology';if(obj)obj.value='discover_market_gaps';stat('launchStatus','Desktop live mode is enabled. Hybrid mode and public-company universe are selected.')}catch(e){}}
function payload(){return {workflow:el('workflowSelect').value,execution_mode:el('executionModeSelect').value,market_universe:el('marketUniverseSelect').value,industry_domain:el('industryDomainSelect').value,buyer_segment:el('buyerSegmentSelect').value,objective:el('objectiveSelect').value,command_id:el('commandSelect').value,signal:el('rawInput').value,count:5}}
function enrichmentHtml(c){
  const e=c.connected_enrichment||{};
  if(!e || !e.safe_to_enrich) return '<div class="field muted"><b>Connected Enrichment:</b> no safe normalized signal match yet</div>';
  const types=(e.top_signal_types||[]).slice(0,3).join(', ')||'connected signal';
  return `<div class="enrichmentBox"><b>Connected Enrichment</b><div>Relevance: ${fmt(e.opportunity_relevance)} (${fmt(e.enrichment_score)}) · Timing: ${fmt(e.timing_window)} · Signals: ${fmt(e.matched_signal_count,0)}</div><div>Types: ${types}</div><div>${fmt(e.connected_thesis)}</div></div>`;
}
function cardHtml(c, isCandidate=true){return `<div class="candidate"><strong>${fmt(c.title)}</strong><div class="field"><b>Market Gap:</b> ${fmt(c.market_gap)}</div><div class="field"><b>Needed Solution:</b> ${fmt(c.needed_solution)}</div><div class="field"><b>Opportunity Direction:</b> ${fmt(c.opportunity_direction)}</div><div class="field"><b>Why Now:</b> ${fmt(c.why_now)}</div>${isCandidate?enrichmentHtml(c):''}${isCandidate?`<div class="field"><b>Selection Score:</b> ${fmt(c.selection_score)} · ${fmt(c.confidence_label)}</div><button data-run="${c.candidate_id}">Run This Opportunity</button>`:''}</div>`}
function fusionHtml(c){
  const f=c.hybrid_fusion||{};
  if(!f || !f.hybrid_score) return '';
  const cls=f.status==='hybrid_ready'?'fusionBox ready':'fusionBox';
  return `<div class="${cls}"><b>Hybrid Fusion</b><div>Readiness: ${fmt(f.hybrid_readiness)} Â· Score: ${fmt(f.hybrid_score)} Â· Mode: ${fmt(f.recommended_mode)}</div><div>${fmt(f.fusion_summary)}</div></div>`;
}
function cardHtml(c, isCandidate=true){return `<div class="candidate"><strong>${fmt(c.title)}</strong><div class="field"><b>Market Gap:</b> ${fmt(c.market_gap)}</div><div class="field"><b>Needed Solution:</b> ${fmt(c.needed_solution)}</div><div class="field"><b>Opportunity Direction:</b> ${fmt(c.opportunity_direction)}</div><div class="field"><b>Why Now:</b> ${fmt(c.why_now)}</div>${isCandidate?enrichmentHtml(c):''}${isCandidate?fusionHtml(c):''}${isCandidate?`<div class="field"><b>Selection Score:</b> ${fmt(c.selection_score)} Â· ${fmt(c.confidence_label)}</div><button data-run="${c.candidate_id}">Run This Opportunity</button>`:''}</div>`}
async function needed(){stat('launchStatus','Searching market-wide needed solution areas...');const x=await api('/api/opportunities/search-needed-solutions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload())});const box=el('candidateList');box.innerHTML='';(x.directions||[]).forEach(c=>{const wrap=document.createElement('div');wrap.innerHTML=cardHtml(c,false);box.appendChild(wrap.firstChild)});stat('launchStatus',`Found ${(x.directions||[]).length} needed solution direction(s).`)}
async function generate(){stat('launchStatus','Generating protected opportunity selection...');const x=await api('/api/opportunities/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload())});const box=el('candidateList');box.innerHTML='';(x.candidates||[]).forEach(c=>{const wrap=document.createElement('div');wrap.innerHTML=cardHtml(c,true);const node=wrap.firstChild;node.querySelector('button').onclick=()=>runCandidate(c.candidate_id);box.appendChild(node)});const ce=x.connected_enrichment||{};stat('launchStatus',`Generated ${(x.candidates||[]).length} opportunity candidate(s). Connected enrichment: ${fmt(ce.enriched_candidate_count,0)}/${fmt((x.candidates||[]).length,0)} enriched from ${fmt(ce.normalized_signal_count,0)} normalized signal(s). Internal construction protected.`)}
async function generate(){stat('launchStatus','Generating protected opportunity selection...');const x=await api('/api/opportunities/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload())});const box=el('candidateList');box.innerHTML='';(x.candidates||[]).forEach(c=>{const wrap=document.createElement('div');wrap.innerHTML=cardHtml(c,true);const node=wrap.firstChild;node.querySelector('button').onclick=()=>runCandidate(c.candidate_id);box.appendChild(node)});const ce=x.connected_enrichment||{};const hf=x.hybrid_fusion||{};stat('launchStatus',`Generated ${(x.candidates||[]).length} opportunity candidate(s). Connected enrichment: ${fmt(ce.enriched_candidate_count,0)}/${fmt((x.candidates||[]).length,0)} enriched from ${fmt(ce.normalized_signal_count,0)} normalized signal(s). Hybrid-ready: ${fmt(hf.hybrid_candidate_count,0)}. Internal construction protected.`)}
async function runCandidate(id){resetEvents();stat('launchStatus','Launching selected opportunity...');const x=await api('/api/opportunities/run-candidate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({candidate_id:id})});if(x.status==='blocked'){stat('launchStatus','Blocked by governance hard stop. See audit panel.',true);loadAuditLog();return}state.active=x.event_run_id;watch()}
function title(r){return r.category_name||r.sector||r.folder_name||r.run_id||'Claire run'}
function renderRuns(){const list=el('runList');list.innerHTML='';el('runCount').textContent=state.runs.length;if(!state.runs.length){list.innerHTML='<div class="status">No runs found.</div>';return} state.runs.forEach(r=>{const d=document.createElement('div');d.className='runCard'+(state.selected&&state.selected.run_id===r.run_id?' active':'');d.innerHTML=`<strong>${fmt(title(r))}</strong><div class="meta">${fmt(r.created_at)}<br>Sector: ${fmt(r.sector)}<br>Decision: ${fmt(r.decision_classification)} · Files: ${fmt(r.written_file_count)}</div>`;d.onclick=()=>selectRun(r);list.appendChild(d)})}
function renderCards(r){const c=[['Run ID',r.run_id],['Output Folder',r.output_dir],['Domain',r.domain],['Sector',r.sector],['Category',r.category_name],['Decision',r.decision_classification],['Breakthrough',r.breakthrough_classification],['Portfolio Score',r.portfolio_score],['Export Level',r.export_package_level],['Export Score',r.export_package_score],['Documents',r.document_count],['Written Files',r.written_file_count]];el('summaryCards').innerHTML=c.map(([a,b])=>`<div class="card"><h3>${a}</h3><p>${fmt(b)}</p></div>`).join('')}
function renderFiles(files){state.files=files||[];el('filesValue').textContent=state.files.length||'—';el('fileList').innerHTML='';el('fileSelect').innerHTML='';state.files.forEach(f=>{const row=document.createElement('div');row.className='fileRow';row.innerHTML=`<div><strong>${f.filename}</strong><div class="muted">${fmt(f.format)} · ${fmt(f.size_bytes)} bytes</div></div><button>Preview</button><button>Open</button>`;row.children[1].onclick=()=>preview(f.filename);row.children[2].onclick=()=>window.open(`/api/runs/${encodeURIComponent(state.selected.run_id)}/files/${encodeURIComponent(f.filename)}?raw=1`,'_blank');el('fileList').appendChild(row);const o=document.createElement('option');o.value=f.filename;o.textContent=f.filename;el('fileSelect').appendChild(o)})}
async function selectRun(r){state.selected=r;renderRuns();el('emptyState').classList.add('hidden');el('detailState').classList.remove('hidden');el('selectedSector').textContent=fmt(r.sector);el('selectedTitle').textContent=title(r);el('selectedMeta').textContent=`${fmt(r.run_id)} · ${fmt(r.created_at)}`;el('decisionValue').textContent=fmt(r.decision_classification);el('exportValue').textContent=fmt(r.export_package_level);renderCards(r);el('rawBox').textContent=JSON.stringify(r,null,2);try{const x=await api(`/api/runs/${encodeURIComponent(r.run_id)}/files`);renderFiles(x.files||[]);const p=['run_summary.md','portfolio_binder.md','README.md'].find(n=>state.files.some(f=>f.filename===n));if(p)preview(p)}catch(e){el('previewBox').textContent=e.message}}
async function preview(name){if(!state.selected||!name)return;el('fileSelect').value=name;el('previewBox').textContent='Loading...';try{const x=await api(`/api/runs/${encodeURIComponent(state.selected.run_id)}/files/${encodeURIComponent(name)}?max_chars=120000`);el('previewBox').textContent=typeof x==='string'?x:(x.content||JSON.stringify(x,null,2));tab('preview')}catch(e){el('previewBox').textContent=e.message}}
function tab(name){document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));['summary','files','preview','raw'].forEach(t=>el(t+'Tab').classList.toggle('hidden',t!==name))}
async function loadRuns(id=null){stat('statusBox','Loading...');try{const x=await api('/api/runs');state.runs=x.runs||[];renderRuns();stat('statusBox',`Loaded ${state.runs.length} run(s).`);const target=id?state.runs.find(r=>r.run_id===id||r.folder_name===id):null;if(target)selectRun(target);else if(state.runs.length&&!state.selected)selectRun(state.runs[0])}catch(e){stat('statusBox','Failed: '+e.message,true)}}
async function rescan(){await api('/api/rescan',{method:'POST'});await loadRuns()}
function resetEvents(){state.cursor=0;el('eventList').innerHTML='';el('progressBar').style.width='0%';el('liveBadge').textContent='running'}
function addEvents(events){for(const ev of events){const d=document.createElement('div');d.className='event '+(ev.event_type==='complete'?'complete':ev.level==='error'?'error':'');d.innerHTML=`<strong>${fmt(ev.stage)} · ${fmt(ev.event_type)}</strong><div>${fmt(ev.message)}</div><div class="muted">${fmt(ev.timestamp)}</div>`;el('eventList').prepend(d);if(ev.progress!==undefined&&ev.progress!==null)el('progressBar').style.width=Math.max(0,Math.min(100,ev.progress))+'%'}}
async function poll(){if(!state.active)return;try{const x=await api(`/api/events/${state.active}?since=${state.cursor}`);addEvents(x.events||[]);state.cursor=x.event_count||state.cursor;if(x.status==='complete'||x.status==='error'){clearInterval(state.timer);state.timer=null;el('liveBadge').textContent=x.status;if(x.result){await loadRuns(x.result.run_id||x.result.folder_name)}stat('launchStatus',x.status==='complete'?'Run complete.':'Run failed: '+fmt(x.error),x.status==='error')}}catch(e){}}
function watch(){stat('launchStatus','Run started. Watching live events...');if(state.timer)clearInterval(state.timer);state.timer=setInterval(poll,900);poll()}
async function launch(){const raw=el('rawInput').value.trim();if(!raw){stat('launchStatus','Add raw input before launching.',true);return}const gov=await governanceCheck();if(gov.decision==='block'){stat('launchStatus','Blocked by governance hard stop. See audit panel.',true);return}const activation=await feedActivationCheck();if(activation.decision==='block'){stat('launchStatus','Feed activation blocked. See activation panel.',true);return}el('runBtn').disabled=true;resetEvents();try{const p=payload();p.raw_input=raw;const x=await api('/api/evaluate/async',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});state.active=x.event_run_id;watch()}catch(e){stat('launchStatus','Run failed to start: '+e.message,true)}finally{setTimeout(()=>{el('runBtn').disabled=false},1200)}}

async function loadFeedStatus(){
  try{
    const x=await api('/api/feeds/status');
    el('feedBadge').textContent=x.feed_layer||'scaffold';
    el('feedStatusBox').textContent=`Connected ingestion: ${x.connected_ingestion_enabled?'enabled':'not enabled'} · Deterministic fallback: ${x.deterministic_fallback_enabled?'ready':'unavailable'} · Coverage universes: ${x.coverage_count}`;
    const list=el('feedCoverageList'); list.innerHTML='';
    (x.coverage||[]).forEach(item=>{
      const d=document.createElement('div'); d.className='feedItem';
      d.innerHTML=`<strong>${item.display_name}</strong><div class="coverage">${item.coverage_target}</div><div class="offline">Connected feed: ${item.connected_feed_enabled?'enabled':'offline scaffold'} · Fallback: ${item.deterministic_fallback?'ready':'unavailable'}</div>`;
      list.appendChild(d);
    });
  }catch(e){
    if(el('feedStatusBox')) el('feedStatusBox').textContent='Feed status unavailable: '+e.message;
  }
}


async function governanceCheck(){
  const p=payload();
  p.raw_input=el('rawInput').value;
  try{
    const x=await api('/api/governance/evaluate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});
    const d=x.decision||{};
    el('governanceBadge').textContent=d.decision||'allow';
    el('governanceStatusBox').textContent=`Decision: ${fmt(d.decision)}\nDefense Classification: ${fmt(d.defense_classification)}\nLegal Status: ${fmt(d.legal_status)}\nSeverity: ${fmt(d.severity)}\nAction: ${fmt(d.recommended_action)}\nReason: ${fmt(d.reason_summary)}`;
    loadAuditLog();
    return d;
  }catch(e){
    el('governanceStatusBox').textContent='Governance check unavailable: '+e.message;
    return {decision:'allow'};
  }
}
async function loadAuditLog(){
  try{
    const x=await api('/api/governance/audit');
    const list=el('auditList'); if(!list) return;
    list.innerHTML='';
    (x.events||[]).slice(0,8).forEach(ev=>{
      const d=document.createElement('div');
      const decision=ev.decision||'allow';
      d.className='auditItem '+(decision==='block'?'block':decision==='review'?'review':'allow');
      d.innerHTML=`<strong>${fmt(ev.event_type)} · ${fmt(decision)}</strong><div>${fmt(ev.defense_classification)} · ${fmt(ev.legal_status)}</div><div class="muted">${fmt(ev.timestamp)}</div>`;
      list.appendChild(d);
    });
  }catch(e){}
}


async function loadFeedActivationStatus(){
  try{
    const x=await api('/api/feeds/activation-status');
    el('activationBadge').textContent=x.activation_layer||'ready';
    el('activationStatusBox').textContent=`Connected ingestion default: ${x.connected_ingestion_default?'enabled':'disabled'}\nDeterministic fallback default: ${x.deterministic_fallback_default?'ready':'unavailable'}\nPolicy: deterministic stays offline; connected/hybrid require allowlisted source and governance check.`;
    loadFeedAudit();
  }catch(e){
    if(el('activationStatusBox')) el('activationStatusBox').textContent='Feed activation status unavailable: '+e.message;
  }
}
async function feedActivationCheck(){
  const p=payload();
  p.raw_input=el('rawInput').value;
  p.signal=el('rawInput').value;
  try{
    const x=await api('/api/feeds/activation-check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});
    const d=x.activation_decision||{};
    el('activationBadge').textContent=d.decision||'ready';
    el('activationStatusBox').textContent=`Decision: ${fmt(d.decision)}\nFeed Status: ${fmt(d.feed_status)}\nConnected Allowed: ${d.connected_ingestion_allowed?'yes':'no'}\nDeterministic Fallback: ${d.deterministic_fallback_allowed?'yes':'no'}\nMode: ${fmt(d.execution_mode)}\nSource Category: ${fmt(d.source_category)}\nReason: ${fmt(d.reason)}`;
    loadFeedAudit();
    return d;
  }catch(e){
    el('activationStatusBox').textContent='Feed activation check unavailable: '+e.message;
    return {decision:'deterministic_only',connected_ingestion_allowed:false};
  }
}
async function loadFeedAudit(){
  try{
    const x=await api('/api/feeds/audit');
    const list=el('activationAuditList'); if(!list) return;
    list.innerHTML='';
    (x.events||[]).slice(0,8).forEach(ev=>{
      const d=document.createElement('div');
      const decision=ev.decision||'deterministic_only';
      d.className='activationDecision '+decision;
      d.innerHTML=`<strong>${fmt(ev.event_type)} · ${fmt(decision)}</strong><div>${fmt(ev.feed_status)} · ${fmt(ev.market_universe)}</div><div class="muted">${fmt(ev.timestamp)}</div>`;
      list.appendChild(d);
    });
  }catch(e){}
}


async function loadPublicCompanySourceCatalog(){
  try{
    const x=await api('/api/feeds/public-company-sources');
    el('sourceCatalogBadge').textContent='cataloged';
    el('sourceCatalogStatusBox').textContent=`Public-company catalog ready.\nSources: ${x.source_count}\nUniverses: ${x.universe_count}\nLive ingestion: not enabled`;
    const list=el('sourceCatalogList'); list.innerHTML='';
    (x.universes||[]).forEach(u=>{
      const d=document.createElement('div'); d.className='sourceItem';
      d.innerHTML=`<strong>${fmt(u.name)}</strong><div class="coverage">${fmt(u.coverage_target)}</div><div class="statusLine">Source category: ${fmt(u.source_category)} · Connected scan: ${fmt(u.connected_scan_status)}</div>`;
      list.appendChild(d);
    });
  }catch(e){
    if(el('sourceCatalogStatusBox')) el('sourceCatalogStatusBox').textContent='Source catalog unavailable: '+e.message;
  }
}


async function loadOfflineUniverseResolver(){
  try{
    const status=await api('/api/feeds/offline-universe/status');
    const p=payload();
    const x=await api('/api/feeds/offline-universe/resolve',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});
    const r=x.resolution||{};
    el('offlineResolverBadge').textContent=status.live_ingestion_enabled?'live':'offline';
    el('offlineResolverStatusBox').textContent=`Universe: ${fmt(r.name)}\nCoverage Target: ${fmt(r.coverage_target)}\nResolution: ${fmt(r.resolution_status)}\nConnected Scan: ${fmt(r.connected_scan_status)}\nDeterministic Fallback: ${r.deterministic_fallback?'ready':'unavailable'}`;
    const list=el('offlineResolverList'); list.innerHTML='';
    (r.coverage_buckets||[]).forEach(bucket=>{
      const d=document.createElement('div'); d.className='offlineBucket';
      d.innerHTML=`<strong>${fmt(bucket.name)}</strong><div>${fmt(bucket.purpose)}</div><div class="lens">${fmt(bucket.opportunity_lens)}</div>`;
      list.appendChild(d);
    });
  }catch(e){
    if(el('offlineResolverStatusBox')) el('offlineResolverStatusBox').textContent='Offline resolver unavailable: '+e.message;
  }
}


async function loadPublicCompanyLiveScanStatus(){
  try{
    const x=await api('/api/feeds/public-company-live/status');
    el('publicLiveScanBadge').textContent=x.live_enabled?'enabled':'disabled';
    el('publicLiveScanStatusBox').textContent=`Scanner: ${fmt(x.scanner)}\nLive Enabled: ${x.live_enabled?'yes':'no'}\nSafe Metadata Only: ${x.safe_metadata_only?'yes':'no'}\nRequires Feed Activation: ${x.requires_feed_activation?'yes':'no'}\nEnable: CLAIRE_ENABLE_LIVE_FEEDS=1 before starting dashboard`;
  }catch(e){
    if(el('publicLiveScanStatusBox')) el('publicLiveScanStatusBox').textContent='Live scan status unavailable: '+e.message;
  }
}
function renderNormalizedSignals(signals, summary={}){
  const list=el('normalizedSignalList'); if(!list) return;
  list.innerHTML='';
  el('normalizedSignalBadge').textContent=String((signals||[]).length);
  el('normalizedSignalStatusBox').textContent=`Normalized: ${(signals||[]).length}\nSafe to enrich: ${fmt(summary.safe_to_enrich_count,0)}\nTop signal type: ${fmt(summary.top_signal_type || (summary.signal_types||[])[0])}\nAverage strength: ${fmt(summary.average_strength_score)}`;
  if(!(signals||[]).length){
    list.innerHTML='<div class="status">Run a public metadata scan or normalize signals to populate this panel.</div>';
    return;
  }
  (signals||[]).forEach(sig=>{
    const d=document.createElement('div');
    const gov=sig.governance_status||'unknown';
    d.className='normalizedSignal '+(sig.safe_to_enrich?'safe':gov==='block'?'block':'review');
    d.innerHTML=`<strong>${fmt(sig.title)}</strong><div>${fmt(sig.summary)}</div><div class="grid"><div><b>Signal Type</b>${fmt(sig.signal_type)}</div><div><b>Market Universe</b>${fmt(sig.market_universe)}</div><div><b>Industry / Domain</b>${fmt(sig.industry_domain)}</div><div><b>Source Category</b>${fmt(sig.source_category)}</div><div><b>Governance Status</b>${fmt(sig.governance_status)}</div><div><b>Opportunity Relevance</b>${fmt(sig.opportunity_relevance)} (${fmt(sig.opportunity_relevance_score)})</div><div><b>Signal Strength</b>${fmt(sig.signal_strength)} (${fmt(sig.signal_strength_score)})</div><div><b>Safe to Enrich</b>${sig.safe_to_enrich?'yes':'no'}</div></div>`;
    list.appendChild(d);
  });
}
async function loadNormalizedSignals(){
  try{
    const x=await api('/api/signals/normalized');
    renderNormalizedSignals(x.signals||[], x.summary||{});
  }catch(e){
    if(el('normalizedSignalStatusBox')) el('normalizedSignalStatusBox').textContent='Normalized signals unavailable: '+e.message;
  }
}
function renderLifecycle(registry, provenance){
  const list=el('lifecycleList'); if(!list) return;
  const stages=(registry&&registry.stages)||[];
  const rules=(provenance&&provenance.threshold_rules)||[];
  const inputs=(provenance&&provenance.calibration_inputs)||[];
  el('lifecycleBadge').textContent=`${stages.length} stages`;
  el('lifecycleStatusBox').textContent=`Stages: ${stages.length}\nThreshold rules: ${rules.length}\nCalibration inputs: ${inputs.length}`;
  list.innerHTML='';
  stages.slice(0,21).forEach(s=>{
    const d=document.createElement('div');
    d.className='lifecycleItem';
    d.innerHTML=`<strong><span class="stageNo">${fmt(s.stage)}.</span> ${fmt(s.name)}</strong><div><span class="category">${fmt(s.category)}</span> · ${fmt(s.output_key)}</div><div>${fmt(s.objective)}</div>`;
    list.appendChild(d);
  });
  rules.slice(0,5).forEach(r=>{
    const d=document.createElement('div');
    d.className='lifecycleItem';
    d.innerHTML=`<strong class="rule">${fmt(r.id)}</strong><div>${fmt(r.metric)}: ${fmt(r.rule)}</div><div>${fmt(r.purpose)}</div>`;
    list.appendChild(d);
  });
}
async function loadLifecycleProvenance(){
  try{
    const registry=await api('/api/lifecycle/stage-registry');
    const provenance=await api('/api/lifecycle/threshold-provenance');
    renderLifecycle(registry, provenance);
  }catch(e){
    if(el('lifecycleStatusBox')) el('lifecycleStatusBox').textContent='Lifecycle provenance unavailable: '+e.message;
  }
}
function renderModeStatus(status){
  const list=el('modeProfileList'); if(!list) return;
  const selected=el('executionModeSelect') ? el('executionModeSelect').value : status.default_mode;
  const profiles=status.profiles||[];
  el('modeBadge').textContent=selected||status.default_mode||'deterministic';
  el('modeStatusBox').textContent=`Controller: ${fmt(status.controller)}\nDefault: ${fmt(status.default_mode)}\nModes: ${(status.supported_modes||[]).join(', ')}`;
  list.innerHTML='';
  profiles.forEach(p=>{
    const d=document.createElement('div');
    d.className='modeProfile'+(p.mode===selected?' active':'');
    d.innerHTML=`<strong>${fmt(p.name)}</strong><div>Connected: ${fmt(p.connected_ingestion)} · Core: ${fmt(p.deterministic_core)} · Fusion: ${fmt(p.hybrid_fusion)}</div><div class="posture">${fmt(p.safety_posture)}</div>`;
    list.appendChild(d);
  });
}
async function loadModeStatus(){
  try{
    const status=await api('/api/modes/status');
    renderModeStatus(status);
  }catch(e){
    if(el('modeStatusBox')) el('modeStatusBox').textContent='Mode governance unavailable: '+e.message;
  }
}
function renderSystemStatus(status){
  const list=el('systemStatusList'); if(!list) return;
  const subs=status.subsystems||[];
  el('systemStatusBadge').textContent=fmt(status.completion_posture);
  el('systemStatusBox').textContent=`Ready: ${fmt(status.ready_subsystem_count,0)}/${fmt(status.subsystem_count,0)}\nNext: ${fmt((status.next_focus||{}).name)}\n${fmt((status.next_focus||{}).reason)}`;
  list.innerHTML='';
  subs.forEach(s=>{
    const d=document.createElement('div');
    d.className='systemItem '+fmt(s.state);
    d.innerHTML=`<strong>${fmt(s.name)}</strong><div><span class="state">${fmt(s.state)}</span></div><div>${fmt(s.detail)}</div>`;
    list.appendChild(d);
  });
}
async function loadSystemStatus(){
  try{
    const status=await api('/api/dashboard/system-status');
    renderSystemStatus(status);
  }catch(e){
    if(el('systemStatusBox')) el('systemStatusBox').textContent='System status unavailable: '+e.message;
  }
}
async function runPublicCompanyLiveScan(){
  stat('launchStatus','Running public-company metadata scan readiness check...');
  const p=payload();
  p.signal=el('rawInput').value;
  p.source_urls=(el('publicSourceUrls').value||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  try{
    const x=await api('/api/feeds/public-company-live/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});
    const list=el('publicLiveScanList'); list.innerHTML='';
    el('publicLiveScanBadge').textContent=x.status||'checked';
    if(x.status!=='success'){
      const d=document.createElement('div'); d.className='publicSignal '+(x.status||'disabled');
      d.innerHTML=`<strong>${fmt(x.status)}</strong><div>${(x.warnings||[]).join(' ') || fmt((x.activation_decision||{}).reason)}</div>`;
      list.appendChild(d);
    }
    (x.signals||[]).forEach(sig=>{
      const d=document.createElement('div'); d.className='publicSignal '+(sig.status||'success');
      d.innerHTML=`<strong>${fmt(sig.title)}</strong><div>${fmt(sig.snippet)}</div><div class="url">${fmt(sig.source_url)}</div>`;
      list.appendChild(d);
    });
    renderNormalizedSignals(x.normalized_signals||[], x.normalized_summary||{});
    el('publicLiveScanStatusBox').textContent=`Status: ${fmt(x.status)}\nRecords: ${fmt(x.record_count || (x.signals||[]).length,0)}\nConnected Allowed: ${((x.activation_decision||{}).connected_ingestion_allowed)?'yes':'no'}\nWarnings: ${(x.warnings||[]).join(' ')}`;
    loadFeedAudit();
  }catch(e){
    el('publicLiveScanStatusBox').textContent='Live scan failed: '+e.message;
  }
}

document.addEventListener('DOMContentLoaded',()=>{loadCatalog().then(applyDesktopLiveMode).then(loadModeStatus);loadSystemStatus();loadPublicCompanySourceCatalog();loadPublicCompanyLiveScanStatus();loadNormalizedSignals();loadLifecycleProvenance();loadOfflineUniverseResolver();loadFeedStatus();loadFeedActivationStatus();loadRuns();el('refreshBtn').onclick=()=>{loadRuns();loadSystemStatus();loadPublicCompanyLiveScanStatus()};if(el('publicLiveScanBtn')) el('publicLiveScanBtn').onclick=runPublicCompanyLiveScan;el('rescanBtn').onclick=rescan;el('neededBtn').onclick=needed;el('generateBtn').onclick=generate;el('runBtn').onclick=launch;el('clearBtn').onclick=()=>{el('rawInput').value='';el('candidateList').innerHTML='';stat('launchStatus','Ready.')};el('loadPreviewBtn').onclick=()=>preview(el('fileSelect').value);document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>tab(b.dataset.tab));['marketUniverseSelect','industryDomainSelect','buyerSegmentSelect','objectiveSelect'].forEach(id=>{const node=el(id); if(node) node.addEventListener('change',()=>loadOfflineUniverseResolver())});const modeSel=el('executionModeSelect'); if(modeSel) modeSel.addEventListener('change',loadModeStatus)});
