# Claire Portable Launch

Use this project folder from a flash drive by opening:

```text
START_CLAIRE_PORTABLE.bat
```

For a safer start that runs the baseline first:

```text
START_CLAIRE_PORTABLE_SAFE.bat
```

The launcher detects its own folder, uses `.venv\Scripts\python.exe` when present, finds an open local port starting at `8765`, starts the dashboard, and opens the browser.

Useful checks:

```powershell
.\.venv\Scripts\python.exe tools\portable_launcher.py --status
.\.venv\Scripts\python.exe tools\run_claire_baseline.py
.\.venv\Scripts\python.exe tools\claire_update_from_url.py --status
```

Keep these folders with the portable copy:

```text
.venv
src
tools
data
exports
tests
```

Live feed fetching remains opt-in. The local dashboard and deterministic/hybrid workflow should run offline from the portable copy.
