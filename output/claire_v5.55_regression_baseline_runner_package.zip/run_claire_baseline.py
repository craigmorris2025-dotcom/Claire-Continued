#!/usr/bin/env python
from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path
from typing import Any, Callable, Dict, List


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC = PROJECT_ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


class BaselineRunner:
    def __init__(self) -> None:
        self.manifest_path = PROJECT_ROOT / "data" / "baselines" / "claire_baseline_manifest.json"
        self.manifest = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        self.results: List[Dict[str, Any]] = []

    def run(self) -> int:
        checks: List[tuple[str, Callable[[], Dict[str, Any]]]] = [
            ("imports", self.check_imports),
            ("stage_registry", self.check_stage_registry),
            ("threshold_provenance", self.check_threshold_provenance),
            ("mode_governance", self.check_mode_governance),
            ("signal_normalization", self.check_signal_normalization),
            ("connected_enrichment", self.check_connected_enrichment),
            ("hybrid_fusion", self.check_hybrid_fusion),
            ("dashboard_status", self.check_dashboard_status),
            ("update_sources", self.check_update_sources),
        ]

        for name, fn in checks:
            self.results.append(self._run_check(name, fn))

        summary = {
            "status": "success" if all(item["status"] == "success" for item in self.results) else "failed",
            "baseline_version": self.manifest["baseline_version"],
            "check_count": len(self.results),
            "passed_count": len([item for item in self.results if item["status"] == "success"]),
            "failed": [item for item in self.results if item["status"] != "success"],
            "results": self.results,
        }
        print(json.dumps(summary, indent=2))
        return 0 if summary["status"] == "success" else 1

    def _run_check(self, name: str, fn: Callable[[], Dict[str, Any]]) -> Dict[str, Any]:
        try:
            payload = fn()
            return {"name": name, "status": "success", **payload}
        except Exception as exc:
            return {
                "name": name,
                "status": "failed",
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }

    def check_imports(self) -> Dict[str, Any]:
        import claire.orchestrator.pipeline_v4  # noqa: F401
        import claire.runtime.dashboard_system_status  # noqa: F401
        import claire.mode.switch_controller  # noqa: F401
        import claire.lifecycle.stage_registry  # noqa: F401
        return {"message": "core package imports succeeded"}

    def check_stage_registry(self) -> Dict[str, Any]:
        from claire.lifecycle.stage_registry import ClaireStageRegistry

        payload = ClaireStageRegistry().as_payload()
        expected_count = self.manifest["expected"]["lifecycle_stage_count"]
        assert payload["stage_count"] == expected_count, payload["stage_count"]
        assert payload["stages"][0]["slug"] == "ingestion"
        assert payload["stages"][-1]["slug"] == "deal_exit_modeling"
        return {"stage_count": payload["stage_count"], "final_stage": payload["final_stage"]}

    def check_threshold_provenance(self) -> Dict[str, Any]:
        from claire.lifecycle.threshold_provenance import ThresholdProvenance

        payload = ThresholdProvenance().as_payload()
        assert payload["threshold_rule_count"] >= self.manifest["expected"]["threshold_rule_minimum"]
        assert payload["calibration_input_count"] >= self.manifest["expected"]["calibration_input_minimum"]
        return {
            "threshold_rule_count": payload["threshold_rule_count"],
            "calibration_input_count": payload["calibration_input_count"],
        }

    def check_mode_governance(self) -> Dict[str, Any]:
        from claire.mode.switch_controller import ModeSwitchController

        controller = ModeSwitchController()
        status = controller.status()
        decision = controller.evaluate({
            "execution_mode": "hybrid",
            "market_universe": "sp500_public",
            "source_category": "public_company_market_data",
            "signal": "public AI infrastructure market pressure",
        })
        assert status["controller"] == self.manifest["expected"]["mode_controller"]
        assert status["supported_modes"] == self.manifest["expected"]["supported_modes"]
        assert decision["requested_mode"] == "hybrid"
        assert decision["effective_mode"] in {"hybrid", "deterministic"}
        return {
            "supported_modes": status["supported_modes"],
            "sample_effective_mode": decision["effective_mode"],
        }

    def check_signal_normalization(self) -> Dict[str, Any]:
        from claire.feeds.signal_normalizer import FeedSignalNormalizer

        normalizer = FeedSignalNormalizer()
        payload = normalizer.normalize_many([
            {
                "signal_id": "baseline_signal_1",
                "status": "success",
                "title": "AI infrastructure governance pressure",
                "summary": "Public metadata indicates AI infrastructure governance and market pressure.",
                "source_category": "public_company_market_data",
                "market_universe": "sp500_public",
                "metadata": {"industry_domain": "information_technology"},
            }
        ], context={
            "market_universe": "sp500_public",
            "industry_domain": "information_technology",
        }, activation_decision={"decision": "allow", "source_category": "public_company_market_data"})
        signal = payload["signals"][0]
        assert payload["normalized_count"] == 1
        assert signal["safe_to_enrich"] is True
        return {
            "normalized_count": payload["normalized_count"],
            "signal_type": signal["signal_type"],
            "opportunity_relevance": signal["opportunity_relevance"],
        }

    def check_connected_enrichment(self) -> Dict[str, Any]:
        from claire.enrichment.connected_opportunity_enricher import ConnectedOpportunityEnricher

        candidate = self._candidate()
        signal = self._normalized_signal()
        enriched = ConnectedOpportunityEnricher().enrich_candidate(candidate, [signal], {
            "execution_mode": "connected",
            "market_universe": "sp500_public",
            "industry_domain": "information_technology",
        })
        enrichment = enriched["connected_enrichment"]
        assert enrichment["safe_to_enrich"] is True
        assert enrichment["matched_signal_count"] >= 1
        return {
            "matched_signal_count": enrichment["matched_signal_count"],
            "opportunity_relevance": enrichment["opportunity_relevance"],
        }

    def check_hybrid_fusion(self) -> Dict[str, Any]:
        from claire.enrichment.connected_opportunity_enricher import ConnectedOpportunityEnricher
        from claire.fusion.hybrid_opportunity_fusion import HybridOpportunityFusionEngine

        enriched = ConnectedOpportunityEnricher().enrich_candidate(
            self._candidate(),
            [self._normalized_signal()],
            {"execution_mode": "hybrid", "market_universe": "sp500_public", "industry_domain": "information_technology"},
        )
        fused = HybridOpportunityFusionEngine().fuse_candidate(enriched, {"execution_mode": "hybrid"})
        fusion = fused["hybrid_fusion"]
        assert fusion["status"] in {"hybrid_ready", "deterministic_only"}
        assert fusion["recommended_mode"] in {"hybrid", "hybrid_candidate", "deterministic"}
        return {
            "fusion_status": fusion["status"],
            "hybrid_readiness": fusion["hybrid_readiness"],
            "recommended_mode": fusion["recommended_mode"],
        }

    def check_dashboard_status(self) -> Dict[str, Any]:
        from claire.runtime.dashboard_system_status import DashboardSystemStatus

        payload = DashboardSystemStatus().build(
            mode_status={"controller": "mode_switch_controller_v1"},
            feed_status={"activation_layer": "ready"},
            signal_status={"status": "success", "signal_count": 1},
            enrichment_status={"status": "success", "safe_to_enrich_count": 1},
            fusion_status={"status": "success", "fusion_engine": "hybrid_opportunity_fusion_v1"},
            lifecycle_status={"status": "success", "stage_count": 21},
            export_summary={"status": "success", "run_count": 0},
            updater_status={"status": "bootstrap_ready"},
        )
        assert payload["dashboard_rollup"] == self.manifest["expected"]["dashboard_rollup"]
        assert payload["subsystem_count"] == 8
        return {
            "subsystem_count": payload["subsystem_count"],
            "completion_posture": payload["completion_posture"],
        }

    def check_update_sources(self) -> Dict[str, Any]:
        path = PROJECT_ROOT / "data" / "update_sources" / "allowed_sources.json"
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
        assert "allowed_sources" in payload or "sources" in payload or isinstance(payload, dict)
        return {"path": str(path), "state": "available"}

    def _candidate(self) -> Dict[str, Any]:
        return {
            "title": "AI infrastructure governance command center",
            "market_universe": "sp500_public",
            "industry_domain": "information_technology",
            "market_gap": "Enterprises need governed AI infrastructure oversight.",
            "needed_solution": "Governance and market-pressure intelligence dashboard.",
            "opportunity_direction": "Build an AI infrastructure governance signal platform.",
            "why_now": "AI governance pressure and infrastructure investment are rising.",
            "selection_score": 0.74,
            "confidence_label": "high",
            "raw_input": "AI infrastructure governance command center for public-company market pressure.",
        }

    def _normalized_signal(self) -> Dict[str, Any]:
        return {
            "signal_id": "baseline_norm_1",
            "market_universe": "sp500_public",
            "industry_domain": "information_technology",
            "source_category": "public_company_market_data",
            "governance_status": "allow",
            "signal_type": "governance / AI infrastructure / market pressure",
            "signal_strength": "medium",
            "signal_strength_score": 0.72,
            "opportunity_relevance": "high",
            "opportunity_relevance_score": 0.82,
            "safe_to_enrich": True,
            "title": "AI infrastructure governance pressure",
            "summary": "Public metadata indicates AI infrastructure governance pressure.",
        }


def main() -> int:
    return BaselineRunner().run()


if __name__ == "__main__":
    raise SystemExit(main())
