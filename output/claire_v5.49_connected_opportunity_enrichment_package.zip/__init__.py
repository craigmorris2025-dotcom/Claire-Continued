"""Connected opportunity enrichment package."""

