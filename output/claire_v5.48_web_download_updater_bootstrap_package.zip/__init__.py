"""Claire updater bootstrap package."""

